import {build} from 'vite';
import {resolve,join} from 'node:path';
import {writeFileSync,readdirSync,readFileSync} from 'node:fs';
const arg=process.argv.indexOf('--out-dir'),out=resolve(arg>=0?process.argv[arg+1]:'dist');
await build({configFile:resolve('vite.static.config.ts'),build:{outDir:out,emptyOutDir:true}});
writeFileSync(join(out,'.nojekyll'),'');
const walk=path=>readdirSync(path,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(join(path,e.name)):[join(path,e.name)]);
for(const file of walk(out).filter(f=>/\.(js|html)$/.test(f))){const text=readFileSync(file,'utf8');if(/signin-with-chatgpt|signout-with-chatgpt|auth\.openai\.com|api\.openai\.com|chatgpt\.site|\/api\/chats|\/api\/learning|huggingface\.co|CreateWebWorkerMLCEngine|navigator\.gpu|2\.4GB|@mlc-ai/.test(text))throw new Error('Unexpected login, model, or previous-host reference in public build: '+file);}
console.log('Lightweight build verified: no login, model download, or AI runtime references.');
