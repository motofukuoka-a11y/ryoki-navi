import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
import {resolve} from 'node:path';
export default defineConfig({root:resolve('static'),base:'./',publicDir:resolve('public'),plugins:[react()],server:{host:'127.0.0.1',port:5178},worker:{format:'es'},build:{outDir:resolve('dist'),emptyOutDir:true}});
