# 旅規ナビ 0.11 — 無料枠のサーバーAI試用版

利用者のブラウザにAIモデルを保存せず、Cloudflare Workers AIのGemma 4で出典付きの参考回答を作る版です。利用者の登録、ChatGPTアカウント、APIキーの入力は不要です。Enterは改行で、送信ボタンだけで送信します。

## 無料枠と停止動作

運用先はWorkers Freeです。有料プランへの変更、AI Gatewayの有料クレジット購入、他社AIへの自動切り替えは行いません。Cloudflareの無料枠は1日10,000 Neuronsで、UTC 0時（日本時間9時）にリセットされます。無料枠を超えるとAI呼び出しは失敗します。アプリはその場合に関連原文を表示し、AI生成できなかったことを明記します。

Workers Freeであることを実際の管理画面で確認するまで、`FREE_PLAN_CONFIRMED=0`のままです。`1`へ変更すると、AIバインディングがある環境でのみ生成を有効にします。プランはアカウント側の設定なので、運用中に有料へ変更しないことが前提です。

独自の「1日20回答」カウンターとD1データベースは使いません。実際の利用可能量はCloudflareの無料枠と同じアカウントの他の利用状況によります。2回の生成（草案・照合）までとし、自動再試行は行いません。

公式条件: https://developers.cloudflare.com/workers-ai/platform/pricing/

## 回答と資料

一般FAQと第190条の券面図案内には、原文のハッシュ等を照合した基本案内を使用します。個別条件を含む質問は検索した原文をAIへ渡します。指定条番号を優先し、未収録の条文や会社の取り扱いを推測で補いません。生成後に出典IDの存在を検証しますが、意味の正しさまで保証するものではありません。

2026年11月19日確認のJR北海道の公開資料35件・760区分を収録しています。省略と未統合の改正があり、JR東日本・ICカード・企画乗車券の専用規則は未収録です。

質問・会話の一部・検索した公開資料をCloudflareで処理します。アプリはサーバーに質問・回答・利用件数を保存しません。画面の会話はメモリ内だけで、再読み込みすると消えます。旧版の個人データや訂正メモには接続しません。追加学習は行いません。

## 開発・公開

1. Node.js 22.13以上で `npm ci`、`npm run typecheck`、`npm run build`、`npm run build:worker`。
2. `npx wrangler dev --config wrangler.preview.jsonc` は外部AIを呼び出さないプレビュー。
3. 運用者がCloudflareへログインし、Workers Freeプランを確認する。利用規約とモデル固有の同意が必要な場合は運用者が確認する。
4. 確認後に `node scripts/confirm-free-plan.mjs --confirmed-workers-free`。
5. `npm run deploy`。初回だけWorkersのサブドメイン作成が必要な場合がある。ドメイン購入は不要。
6. 実URLでAI回答・出典・Enterの改行・匿名アクセスを確認する。

GitHub Pagesを入口として残す場合は、実際の公開URLを `VITE_API_BASE` に設定してフロントエンドをビルドし、既存の公開ファイルを更新します。未設定URLや、AI未接続の試作で公開版を置き換えません。

構成の中心は `server/handler.ts`、`lib/guest-answer.ts`、`lib/answer-plan.ts`、`components/rail-chat.tsx` です。将来の自宅サーバーではAI呼び出し部分をローカル推論へ置き換えられます。
