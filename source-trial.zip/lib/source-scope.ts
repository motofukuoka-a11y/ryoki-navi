import type {Source} from './rail';
const hasIC=(q:string)=>/kitaca|キタカ|suica|スイカ|pasmo|icoca|sugoca|toica|manaca|nimoca|はやかけん|pitapa|sapica|サピカ|icカード|ic乗車|交通系ic|ic第|ic別表/i.test(q.normalize('NFKC'));
export const icQuestion=(q:string)=>{const latest=q.split('追加・訂正条件: ').at(-1)!;return q.includes('追加・訂正条件: ')&&/旅客営業規則|旅客規則|普通乗車券|紙のきっぷ/.test(latest)&&!hasIC(latest)?false:hasIC(q);};

export const icSource=(s:Source)=>s.article.startsWith('IC')||/Kitaca|キタカ|SAPICA|サピカ/i.test(s.title)||/\/kitaca\/|\/suica\/area\/hokkaido|20261118_KO_Kitaca|sapica.jp|hakobus.co.jp/.test(s.documentUrl);
export const authoritative=(s:Source)=>s.evidence==='official_text'||s.evidence==='official_web';
export function scopedArticles(q:string,articles:string[]){return icQuestion(q)&&!/旅客営業規則|旅客規則/.test(q)?articles.map(a=>a.startsWith('第')?'IC'+a:a):articles;}
export const availableSource=(s:Source,date:string)=>(!s.effectiveFrom||s.effectiveFrom<=date)&&(!icSource(s)||date>=s.snapshotDate);
