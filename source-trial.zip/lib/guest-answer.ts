import {assistance,resolvedQuestion} from './question-intent';
import {answerLight} from './light-answer';
import {referenceAnswer} from './reference';
import {quickGuide} from './quick-guide';
import {type Company} from './rail';
import {makeAnswerPlan} from './answer-plan';
import {articleNumbers,matchingArticleParts,collectEvidence} from './smart-retrieval';
import {scopedArticles,icQuestion} from './source-scope';

// Only bundled public JR documents are used. Personal records are never accessed.
export function prepareAnswer(question:string,company:Company,date:string,history:{role:string;content:string}[],enabled:boolean,ready:boolean){
 const help=assistance(question,company,date,history);if(help)return{answer:help};
 const query=resolvedQuestion(question,history),continues=history.length>0;
 const fallback=()=>answerLight({question,company,journeyDate:date,history,guideEnabled:false});
 const unsupported=company!=='hokkaido'||(/JR東日本|ＪＲ東日本/.test(question)&&!icQuestion(question))||/企画乗車券|フリーきっぷ|おトクなきっぷ|青春18|えきねっと|トクだ値/i.test(continues?query:question);
 if(unsupported||!enabled)return{answer:fallback()};
 if(/^(こんにちは|こんばんは|おはようございます|おはよう|ありがとう(?:ございます)?)[。！!\s]*$/.test(question))return{answer:answerLight({question,company,journeyDate:date,history,guideEnabled:true})};
 const articles=scopedArticles(question,articleNumbers(question)),parts=matchingArticleParts(question,company,date);
 const figureRequest=articles.length===1&&articles[0]==='第190条'&&/様式|券面|図|省略|準常備/.test(question);
 if(figureRequest){const guide=referenceAnswer(question,company,date);if(guide)return{answer:{...guide,question}};}
 const quick=quickGuide(question,company,date,history);if(quick)return{answer:{...quick,question}};
 if(!ready)return{answer:{...fallback(),notice:'回答サービスを利用できないため、関連する公式資料を表示します。'}};
 if(articles.length&&(articles.some(a=>!parts.some(s=>s.article===a))||articles.length>8))return{answer:fallback()};
 const strict=articles.length>0&&/だけ|のみ|限定/.test(question);
 const sources=strict?collectEvidence(question,company,date,{resolvedQuestion:query,articles,queries:[]},true):[];
 const plan=makeAnswerPlan(question,company,date,history,sources);
 return{plan,sources,query,strict,lookup:!strict,fallback:fallback()};
}
