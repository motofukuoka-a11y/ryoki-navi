import {answerLight} from './light-answer';
import {referenceAnswer} from './reference';
import {quickGuide} from './quick-guide';
import {type Company} from './rail';
import {makeAnswerPlan} from './answer-plan';
import {articleNumbers,matchingArticleParts,collectEvidence} from './smart-retrieval';

// Only bundled public JR documents are used. Personal records are never accessed.
export function prepareAnswer(question:string,company:Company,date:string,history:{role:string;content:string}[],enabled:boolean,ready:boolean){
 const previous=history.filter(m=>m.role==='user').slice(-3).map(m=>m.content).join(' ');
 const continues=/^(それ|その|では|じゃ|同じ条件|この場合|いくら|何日|何円|手数料は|有効日数は|なぜ|どうして|つまり|戻る|帰り|普通乗車券なら|普通のきっぷなら)/.test(question);
 const query=continues&&previous?previous+' '+question:question;
 const fallback=()=>answerLight({question,company,journeyDate:date,history,guideEnabled:false});
 const unsupported=company!=='hokkaido'||/JR東日本|ＪＲ東日本|kitaca|suica|pasmo|icoca|sugoca|toica|manaca|nimoca|はやかけん|icカード|ic乗車|企画乗車券|フリーきっぷ|おトクなきっぷ|青春18|えきねっと|トクだ値/i.test(continues?query:question);
 if(unsupported||!enabled)return{answer:fallback()};
 if(/^(こんにちは|こんばんは|おはようございます|おはよう|ありがとう(?:ございます)?)[。！!\s]*$/.test(question))return{answer:answerLight({question,company,journeyDate:date,history,guideEnabled:true})};
 const articles=articleNumbers(question),parts=matchingArticleParts(question,company,date);
 const figureRequest=articles.length===1&&articles[0]==='第190条'&&/様式|券面|図|省略|準常備/.test(question);
 if(figureRequest){const guide=referenceAnswer(question,company,date);if(guide)return{answer:{...guide,question}};}
 const quick=quickGuide(question,company,date,history);if(quick)return{answer:quick};
 if(!ready)return{answer:{...fallback(),notice:'サーバーAIは準備中です。現在は関連する原文を表示しています。'}};
 if(articles.length&&(articles.some(a=>!parts.some(s=>s.article===a))||articles.length>8))return{answer:fallback()};
 const strict=articles.length>0&&/だけ|のみ|限定/.test(question);
 const sources=strict?collectEvidence(question,company,date,{resolvedQuestion:query,articles,queries:[]},true):[];
 const plan=makeAnswerPlan(question,company,date,history,sources);
 return{plan,sources,query,strict,lookup:!strict,fallback:fallback()};
}
