import corpus from '../data/corpus.json';
import {answerLight} from './light-answer';
import {referenceAnswer} from './reference';
import {retrieve,type Company,type Source} from './rail';
import {makeAnswerPlan} from './answer-plan';

const chunks=corpus.chunks as Source[];
const basicQuestions=new Set([
 '普通乗車券で途中下車できる条件は？',
 '使う前の乗車券を払い戻したい。条件と手数料は？',
 '乗車券の有効期間は、どのように決まりますか？',
 '猫を列車に持ち込む条件は？'
]);

// Only bundled public JR documents are used. Personal cloud records are never accessed.
export function prepareAnswer(question:string,company:Company,date:string,history:{role:string;content:string}[],enabled:boolean,ready:boolean){
 const continues=/^(それ|その|では|じゃあ|同じ条件|この場合|いくら|何日|何円|手数料は|有効日数は)/.test(question);
 const previous=history.filter(m=>m.role==='user').slice(-1).map(m=>m.content).join(' ');
 const query=continues?previous+' '+question:question;
 const fallback=()=>answerLight({question,company,journeyDate:date,history,guideEnabled:false});
 const unsupported=company!=='hokkaido'||/JR東日本|ＪＲ東日本|kitaca|suica|pasmo|icoca|sugoca|toica|manaca|nimoca|はやかけん|icカード|ic乗車|企画乗車券|フリーきっぷ|おトクなきっぷ|青春18|えきねっと|トクだ値/i.test(query);
 if(unsupported||!enabled)return{answer:fallback()};
 if(/^(こんにちは|こんばんは|おはようございます|おはよう|ありがとう(?:ございます)?)[。！!\s]*$/.test(question))return{answer:answerLight({question,company,journeyDate:date,history,guideEnabled:true})};
 const articles=[...new Set([...query.normalize('NFKC').matchAll(/第\s*(\d+)\s*条(?:\s*の\s*(\d+))?/g)].map(m=>'第'+m[1]+'条'+(m[2]?'の'+m[2]:'')))];
 const figureRequest=articles.length===1&&articles[0]==='第190条'&&/様式|券面|図|省略|準常備/.test(query);
 // Fixed guides are reserved for general FAQ questions. Conditions in other questions go to AI.
 if(basicQuestions.has(question)||figureRequest){const guide=referenceAnswer(query,company,date);if(guide)return{answer:{...guide,question}};}
 if(!ready)return{answer:{...fallback(),notice:'サーバーAIは準備中です。現在は関連する原文を表示しています。'}};
 let sources:Source[];
 if(articles.length){
  const matching=chunks.filter(s=>s.company===company&&s.evidence==='official_text'&&articles.includes(s.article)&&(!s.effectiveFrom||s.effectiveFrom<=date));
  if(articles.some(article=>!matching.some(s=>s.article===article))||articles.length>4)return{answer:fallback()};
  sources=articles.map(article=>matching.find(s=>s.article===article)!);
 }else{
  const guide=referenceAnswer(query,company,date);
  sources=[...new Map([...(guide?.sources??[]),...retrieve(query,company,date,6)].filter(s=>s.evidence!=='editorial_note'&&(!s.effectiveFrom||s.effectiveFrom<=date)).map(s=>[s.id,s])).values()].slice(0,4);
 }
 if(!sources.length)return{answer:fallback()};
 const plan=makeAnswerPlan(question,company,date,history,sources,'質問に対する結論を最初に答える。条件が不足する場合は、必要な確認点を具体的に示す。');
 return{plan,sources:sources.slice(0,plan.sourcesCount),fallback:fallback()};
}
