import type {Answer,Company,Source,Section} from './rail';
import {availableSource,icQuestion} from './source-scope';
import {evidenceUnits} from './evidence';
import structure from '../data/document-structure.json';
export function topicGuide(q:string,company:Company,date:string,all:Source[]):Answer|null{
 if(/第\s*\d+\s*条/.test(q)&&/だけ|のみ|限定/.test(q))return null;
 const find=(article:string)=>all.find(s=>s.article===article&&s.company===company&&availableSource(s,date)&&['official_text','official_web'].includes(s.evidence));
 const faq=(file:string)=>all.find(s=>s.documentUrl.endsWith('/'+file+'.html')&&availableSource(s,date));
 const section=(heading:string,body:string,s:Source):Section=>({heading,body,source_ids:[s.id],evidence:[...new Map([...evidenceUnits(s,'S1').filter(u=>/過剰額/.test(u.quote)),...evidenceUnits(s,'S1')].map(u=>[u.id,u])).values()].slice(0,3).map(u=>({source_id:s.id,quote:u.quote}))});
 const make=(summary:string,sections:Section[],sources:Source[],followup:string[]=[]):Answer=>({id:crypto.randomUUID(),question:q,company,journeyDate:date,summary,sections,sources,followup,assumptions:['公式公開資料に基づく一般案内です。利用日と券種に対応する条件・例外を、出典で確認してください。'],mode:'reference',confidence:'conditional',notice:'原文と照合した基本案内です。'});
 if(/何条(?:から|まで|ある|で|に|分|構成)|何章|目次|全体.*構成|規則.*構成|最終.*条|最後.*条|条文.*数|全部で.*条/.test(q)){
  const ic=icQuestion(q)&&!/旅客営業規則|旅客規則/.test(q),s=find(ic?'IC規則の構成':'旅客営業規則の構成');if(!s)return null;
  const range=ic?structure.ic:structure.passenger;
  return make((ic?'ICカード乗車券取扱規則':'旅客営業規則')+'の条番号は、第'+range.first+'条から第'+range.last+'条までです。',[
   section('規則全体の構成',ic?'総則と旅客営業などから成り、本文の後に附則・別表があります。旅客営業規則の条番号とは別です。':'第1編「総則」と、第2編「旅客営業」から成ります。第2編は第1章「通則」から第11章「携帯品の一時預り」までです。',s),
   section('条番号と条文数の違い','これは先頭と末尾の条番号です。枝番や削除・省略があるため、「有効な条文がちょうど'+range.last+'個ある」という意味ではありません。'+(/目次|何章|構成/.test(q)&&!ic?'\n'+structure.passenger.chapters.map(c=>c.title).join('\n'):''),s)
  ],[s]);
 }
 if(/Kitaca|キタカ/i.test(q)&&/発行|発売|購入|買え|買い|買う|欲し|郵送|作れ|作る|申し込/.test(q)&&!/紛失|再発行|障害|定期|障がい|障害者|小児|子供|子ども|何円|いくら|クレジット(?:カード)?(?:で|払い|支払)|無記名.*記名|記名.*変更|チャージ|払いもど|払い戻|どこまで|利用エリア|乗れる|使える|使えます/.test(q)){
  const s=faq('qa0103'),t=faq('qa0061');if(!s||!t)return null;
  return make('通常のKitacaはKitacaエリア内の発売駅で購入します。道外からは、郵送で申し込めるクレジットカード一体型という方法があります。',[
   section('通常のKitacaを購入する場合','発売箇所は、Kitacaエリア内のKitaca発売駅（有人駅）です。通常のKitacaの郵送販売は行っていません。道外のSuica等の利用エリアでKitacaそのものを発売しているという意味ではありません。',t),
   section('クレジットカード一体型の場合','クレジットカード一体型Kitacaは、申し込み・カードの届け先ともに郵送に対応しているため、道外に住んでいても申し込めます。手続きや発行条件は各クレジットカード会社へ確認してください。',s)
  ],[t,s]);
 }
 if(/経路|ルート|山線|海線/.test(q)&&/変更|変え|差額|戻/.test(q)&&!/IC|Kitaca|キタカ|Suica|定期|回数|特急|急行|指定席|グリーン|寝台|企画|フリー|パス|運休|不通|運行不能|災害|代行|取消|キャンセル|途中下車|旅行中止|打切|往復|連続|変更済|2回|二回|変更した.*変更/i.test(q)){
  const before=find('第248条'),after=find('第249条');if(!before||!after)return null;
  const knownBefore=/使用(?:開始)?前|旅行開始前|乗車前|乗る前|未使用|使う前|改札.*(?:入る前|入っていない)/.test(q),knownAfter=/使用(?:開始)?後|旅行開始後|乗車後|乗った後|乗ってから|乗車中|途中で|改札.*入った/.test(q);
  const summary=knownBefore&&!knownAfter?'使用開始前の普通乗車券を所定の手続きで変更する場合、変更後が安ければ差額は払い戻されます。':knownAfter&&!knownBefore?'使用開始後の普通乗車券を本人都合で別経路に変更する場合、運賃が安くなっても過剰額は払い戻されません。':'差額が戻るかは、きっぷの種類と、使用開始前・開始後のどちらで経路を変更したかによって異なります。';
  return make(summary,[
   section('使用開始前の変更','普通乗車券などは、旅行・使用開始前にあらかじめ係員へ申し出て承諾を受け、原則1回に限り同種類のきっぷへ変更できます。第248条第6項では、支払済みと変更後の運賃・料金を比較し、不足額を収受し、過剰額を払い戻すと定めています。',before),
   section('使用開始後の経路変更','普通乗車券を別経路へ変更する場合、第249条第2項第1号イ（ロ）は、変更区間の普通旅客運賃と元のきっぷの不乗区間の運賃を比較し、不足額は収受し、過剰額は払い戻さないと定めています。事前の申し出と係員の承諾が必要です。距離等による計算上の例外は原文で確認します。',after)
  ],[before,after],[...(!/普通(?:乗車券|のきっぷ)/.test(q)?['お持ちのきっぷは普通乗車券ですか？ 特急券・定期券・企画券などは別の取扱いです。']:[]),...(!knownBefore&&!knownAfter?['経路を変更したのは、きっぷを使う前ですか、使い始めた後ですか？']:[]) ,'運休に伴う変更は別の取扱いです。具体的な差額は、元のきっぷの券面と変更区間を確認する必要があります。']);
 }
 return null;
}
