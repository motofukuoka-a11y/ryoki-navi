import type {Answer,Source,Section,Company} from './rail';
import {evidenceUnits} from './evidence';
export function validateAnswer(value:unknown,sources:Source[]){if(!value||typeof value!=='object')throw new Error('回答形式を確認できませんでした。');const v=value as Record<string,unknown>,known=new Map(sources.map(s=>[s.id,s]));if(typeof v.summary!=='string'||!Array.isArray(v.sections)||!Array.isArray(v.followup)||!Array.isArray(v.assumptions)||!['supported','conditional','insufficient'].includes(String(v.confidence)))throw new Error('回答形式を確認できませんでした。');const sections=v.sections as Section[];for(const s of sections)if(typeof s.heading!=='string'||typeof s.body!=='string'||!Array.isArray(s.source_ids)||s.source_ids.some(id=>!known.has(id)))throw new Error('出典を確認できない回答を除外しました。');const cited=sections.flatMap(s=>s.source_ids).map(id=>known.get(id)!);if(v.confidence==='supported'&&(!cited.length||sections.some(s=>!s.source_ids.length)))v.confidence='insufficient';if(v.confidence==='supported'&&cited.some(s=>s.evidence==='editorial_note'))v.confidence='conditional';return{summary:v.summary,sections,confidence:v.confidence as Answer['confidence'],followup:(v.followup as unknown[]).filter((x):x is string=>typeof x==='string'),assumptions:(v.assumptions as unknown[]).filter((x):x is string=>typeof x==='string')};}

export function finishAnswer(value:unknown,sources:Source[],question:string,company:Company,date:string):Answer{
 if(!value||typeof value!=='object'||JSON.stringify(value).length>16000)throw new Error('回答の形式または長さを確認してください。');
 const result=structuredClone(value) as {confidence?:unknown;followup?:unknown;assumptions?:unknown;sections?:{heading:string;body:string;evidence_ids?:string[];source_ids?:string[];evidence?:{source_id:string;quote:string}[]}[]};
 result.confidence=result.confidence==='insufficient'?'insufficient':'conditional';
 result.followup??=[];result.assumptions??=[];
 const known=new Map(sources.flatMap((source,i)=>evidenceUnits(source,'S'+(i+1)).map(unit=>[unit.id,{source_id:source.id,quote:unit.quote}] as const)));
 const summaryIds=(result as {summary_evidence_ids?:unknown}).summary_evidence_ids;
 if(summaryIds!==undefined&&(!Array.isArray(summaryIds)||!summaryIds.length||summaryIds.length>3||summaryIds.some(id=>typeof id!=='string'||!known.has(id))))throw new Error('結論の根拠を確認できませんでした。');
 if(Array.isArray(result.sections))for(const section of result.sections){
  if(!section||!Array.isArray(section.evidence_ids)||!section.evidence_ids.length||section.evidence_ids.length>3)throw new Error('原文の参照を確認できませんでした。');
  section.evidence=[...new Set(section.evidence_ids)].map(id=>{const evidence=known.get(id);if(!evidence)throw new Error('原文の参照を確認できませんでした。');return evidence;});
  section.source_ids=[...new Set(section.evidence.map(e=>e.source_id))];
  delete section.evidence_ids;
 }
 if(!result.sections?.length&&result.confidence!=='insufficient')throw new Error('回答の根拠を確認できませんでした。');
 const checked=validateAnswer(result,sources);
 if(checked.sections.length>4||checked.sections.some(s=>s.body.length>3000||!s.source_ids.length))throw new Error('回答の出典または長さを確認できませんでした。');
 const used=new Set(checked.sections.flatMap(s=>s.source_ids));
 if(Array.isArray(summaryIds))for(const id of summaryIds)used.add(known.get(id)!.source_id);
 return{...checked,assumptions:['JR北海道の収録資料の抜粋に基づく参考回答です。公開資料には省略と未統合の改正があり、指定日の取扱いは原文での確認が必要です。'],confidence:checked.confidence==='supported'?'conditional':checked.confidence,id:crypto.randomUUID(),question,company,journeyDate:date,mode:'ai',notice:'サーバAIによる参考回答です。出典の記載と意味が一致するか、原文でご確認ください。',sources:sources.filter(s=>used.has(s.id))};
}
