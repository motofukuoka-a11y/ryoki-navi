import {conditionProfile} from '../server/conditions';
import type {Answer,Company,Source} from './rail';

// A reviewed calculation for explicitly stated ordinary-train unreserved travel.
// Unhandled ages, extra conditions and other purposes return to the normal reader.
export function passengerFareGuide(question:string,company:Company,date:string,sources:Source[]):Answer|null{
 const p=conditionProfile(question);
 if(company!=='hokkaido'||p.topic!=='children'||p.focus.join()!=='count'||p.seats.join()!=='local,unreserved'||p.numbers.length!==3||p.route.length||p.temporal.length||p.usage.length||p.animals.length||p.negations.length||p.articles.length||p.tickets.some(t=>t!=='ordinary'))return null;
 if(/団体|指定|uシート|u-seat|寝台|グリーン|特別車両|特急|新幹線|定期|企画|回数|障害|割引|未就学|無効|貸切|学校|持っていない|所持しない|持たない|購入していない|持ってない|除く|以外|だけで|だけが/i.test(question))return null;
 const adult=p.numbers.find(n=>n.startsWith('persons:adult:')),young=p.numbers.find(n=>/^persons:age_[1-5]:/.test(n));
 if(!adult||!young)return null;
 const adults=Number(adult.split(':')[2]),children=Number(young.split(':')[2]),age=Number(young.split(':')[1].slice(4));
 if(!p.numbers.includes('age::'+age+':')||!Number.isSafeInteger(adults)||!Number.isSafeInteger(children)||adults<1||children<1||adults>10||children>10)return null;
 const source=sources.find(s=>s.company===company&&s.article==='第73条'&&s.evidence==='official_text'&&(!s.effectiveFrom||s.effectiveFrom<=date));
 if(!source||!source.text.replace(/\s/g,'').includes('ただし、2人を超えた者だけ小児とみなす。'))return null;
 const free=Math.min(children,2*adults),paid=children-free;
 return{id:crypto.randomUUID(),question,company,journeyDate:date,mode:'reference',confidence:'conditional',summary:'ご質問の条件では、小児運賃が必要な幼児は'+paid+'人分です。',sections:[{heading:'人数を対象別に計算',body:age+'歳の子'+children+'人は幼児です。乗車券を所持する6歳以上の付き添いが大人'+adults+'人の場合、幼児を無賃とする人数は付き添い1人につき2人までです。したがって、幼児'+children+'人のうち'+free+'人が無賃、残る'+paid+'人を小児とみなします。「2人を超える」は随伴する幼児の人数を数えます。',source_ids:[source.id]}],sources:[source],followup:[],assumptions:['大人は有効な乗車券を所持し、幼児を随伴して旅行する前提です。団体旅客ではなく、普通列車の自由席を利用する場合の人数計算です。','収録資料に基づく一般案内です。公開資料の省略・未統合の改正と利用日への適用は、原文で確認してください。'],notice:'原文と照合した人数計算を表示しています。追加条件を含む場合はAIが関連条文を参照します。'};
}
