import type {Source} from './rail';
export function evidenceUnits(source:Source,alias:string){
 const text=source.text.replace(/\s+/g,'');
 const sentences:string[]=[];let depth=0,start=0;
 for(let i=0;i<text.length;i++){
  if('（('.includes(text[i]))depth++;
  if('）)'.includes(text[i]))depth=Math.max(0,depth-1);
  if(text[i]==='。'&&depth===0){sentences.push(text.slice(start,i+1));start=i+1;}
 }
 if(start<text.length)sentences.push(text.slice(start));
 const units:string[]=[];let pending='';
 for(const sentence of sentences){
  if(pending&&pending.length+sentence.length>320){units.push(pending);pending='';}
  if(sentence.length>320){for(let i=0;i<sentence.length;i+=260)units.push(sentence.slice(i,i+320));}
  else pending+=sentence;
 }
 if(pending)units.push(pending);
 return units.filter(Boolean).map((quote,i)=>({id:alias+'.P'+(i+1),quote}));
}
