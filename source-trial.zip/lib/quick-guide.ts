import corpus from '../data/corpus.json';
import {sha256} from '@noble/hashes/sha2.js';
import {bytesToHex} from '@noble/hashes/utils.js';
import {referenceAnswer} from './reference';
import {evidenceUnits} from './evidence';
import type {Answer,Company,Source} from './rail';
// Only reviewed public FAQs are stored. No visitor questions or answers are cached.
// Any change to the corpus disables these guides until they are reviewed again.
const reviewedCorpusHash='e5bd1b0e64e400b2decc4494feed6cd981d5a0874179929674c0031cd83e103d';
const reviewed=bytesToHex(sha256(new TextEncoder().encode(JSON.stringify(corpus))))===reviewedCorpusHash;
const normalize=(q:string)=>q.normalize('NFKC').replace(/\s+/g,'').replace(/[?？。!！]+$/u,'');
const generic=new Set(['普通乗車券で途中下車できる条件は','使う前の乗車券を払い戻したい。条件と手数料は','乗車券の有効期間は、どのように決まりますか','猫を列車に持ち込む条件は'].map(normalize));
const commuter=new Set(['定期券で乗り越した場合、誤乗扱いになりますか','定期券で乗り越したら誤乗扱いになりますか'].map(normalize));
export function quickGuide(question:string,company:Company,date:string,history:{role:string;content:string}[]):Answer|null{
 if(!reviewed||company!=='hokkaido'||history.length)return null;
 const key=normalize(question);
 const raw=key.match(/^第(\d+)条(?:の(\d+))?(?:の)?(?:原文|条文|収録本文)(?:を)?(?:(?:見せて|表示して|教えて)(?:ください|下さい)?)?$/u);
 if(raw){
  const article='第'+raw[1]+'条'+(raw[2]?'の'+raw[2]:'');
  const sources=(corpus.chunks as Source[]).filter(s=>s.company===company&&s.article===article&&s.evidence==='official_text'&&(!s.effectiveFrom||s.effectiveFrom<=date));
  if(!sources.length)return null;
  return {id:crypto.randomUUID(),question,company,journeyDate:date,mode:'reference',confidence:'conditional',summary:article+'の収録原文を表示します。',sections:sources.map(s=>({heading:s.title+(s.page?'（PDF '+s.page+'ページ）':''),body:s.text,source_ids:[s.id]})),sources,followup:[],assumptions:['公開資料の収録範囲を表示しています。省略・未統合の改正があり、現行全文と同一とは限りません。'],notice:'保存した原文をそのまま表示しています。AIによる要約・解釈は行っていません。'};
 }

 if(generic.has(key)){const answer=referenceAnswer(question,company,date);return answer&&answer.sources.every(s=>!s.effectiveFrom||s.effectiveFrom<=date)?answer:null;}
 if(!commuter.has(key))return null;
 const source=(corpus.chunks as Source[]).find(s=>s.article==='第291条'&&s.evidence==='official_text'&&(!s.effectiveFrom||s.effectiveFrom<=date));
 if(!source)return null;
 return {id:crypto.randomUUID(),question,company,journeyDate:date,mode:'reference',confidence:'conditional',summary:'定期券は、第291条の「誤乗区間の無賃送還」の対象外です。',sections:[{heading:'定期券を除外する規定',body:'第291条は、対象となる旅客から「定期乗車券又は普通回数乗車券を使用する旅客」を除外しています。そのため、定期券で区間外へ誤って乗り越した場合、この条文に基づく無賃送還の取扱いは受けられません。',source_ids:[source.id],evidence:evidenceUnits(source,'S1').slice(0,1).map(u=>({source_id:source.id,quote:u.quote}))}],sources:[source],followup:[],assumptions:['収録資料に基づいて原文と照合した一般案内です。公開資料の省略・未統合の改正と利用日への適用は、原文で確認してください。'],notice:'確認済みの基本案内を表示しています。個別条件を含む別の質問には、AIが関連条文を参照して回答します。'};
}
