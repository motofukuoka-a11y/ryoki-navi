import {sha256} from '@noble/hashes/sha2.js';
import {bytesToHex} from '@noble/hashes/utils.js';
import corpus from '../data/corpus.json';
import type {Answer,Company,Source,Section} from './rail';
const chunks=corpus.chunks as Source[];
const hashes:Record<string,string>={'第156条':'83a77a9f66a2b1b497647049e82df1aa3ca11628f5577f3bfcb3d173e09f4bb7','第230条':'faed3c3e1b2c850ab99806168320eb5b2b00a2656ed66faec91997efd4de4b5a','第154条':'26d1f1c4965c7298381372c4530c3d6a3db6f5d882fdf3af7818729c1589b4b2','第271条':'817ceab9e506d69bcad73381a3fe228228b029b5d097f005a73d1f7df64ff2cb','第308条':'3b1c53dd1bb985e694552e070f10f87fb67089e6c0323885f7827eeb87ca5814','第309条':'8ce1ffdcbc1b175ffae9b067a0c560e318e19c0a42a0ff98aa19013965d81ae1','第310条':'a7570c5959aa4415c63f52ef85860e4a3353b17ae2a5bfd3034de3a9cdb9799b'};
function article(n:string){const s=chunks.find(x=>x.article===n&&x.evidence==='official_text');if(!s||!hashes[n]||bytesToHex(sha256(new TextEncoder().encode(s.text)))!==hashes[n])return null;return s;}
// These guides are tied to the reviewed source text. A changed article disables its guide.
export function referenceAnswer(question:string,company:Company,date:string):Answer|null{
 if(company!=='hokkaido')return null;
 const make=(summary:string,sections:Section[],sources:Source[],followup:string[]=[]):Answer=>({id:crypto.randomUUID(),question,company,journeyDate:date,mode:'reference',confidence:'conditional',summary,sections,sources,followup,assumptions:['JR北海道の2026年4月1日公開版等の収録資料に基づく一般案内です。利用日への改正適用と個別条件は確認が必要です。'],notice:'収録原文に基づいて作成した基本案内です。出典と、該当する条件・ただし書を併せてご確認ください。'});
 if(/途中下車/.test(question)&&!/190条|準常備/.test(question)){
  const s=article('第156条'),t=article('第230条');if(!s||!t)return null;
  return make('普通乗車券は原則として途中下車できますが、距離・利用区間・券面の表示などによって例外があります。',[
   {heading:'「途中下車」の意味',body:'第156条では、旅行開始後、券面の発着区間内の着駅以外の駅で出場し、再び列車に乗り継いで旅行を続ける取扱いを定めています。原則として可能で、同条に列挙された駅が例外です。',source_ids:[s.id]},
   {heading:'主な例外と確認条件',body:'全区間の営業キロが100kmまでの普通乗車券、大都市近郊区間内相互発着の普通乗車券などには、途中下車の制限があります。特定都区市内・東京山手線内の表示がある乗車券に関する例外は、券面に表示されたそのエリア内の駅についてのものです。普通回数乗車券・区間変更時の規定や、会社指定の接続駅等に関するただし書もあるため、個別の可否は原文で確認します。',source_ids:[s.id]},
   {heading:'利用時の手続き',body:'第230条は、旅行開始時の入鋏等、途中下車時の途中下車印、乗継時の改札、旅行終了時の乗車券の引渡しを定めています。',source_ids:[t.id]}
  ],[s,t],['具体的な可否を調べる場合は、きっぷの種類、券面の発着駅・市内表示、経路、途中下車したい駅を確認してください。']);
 }
 if(/190条|準常備.*様式/.test(question)){
  const base=chunks.find(s=>s.article==='第190条'&&s.evidence==='official_text'&&s.note.includes('省略'));
  const figures=chunks.filter(s=>s.evidence==='amendment'&&s.documentUrl.endsWith('yakkan_info_20260310_09.pdf')&&(s.page===74||s.page===75));
  if(!base||figures.length!==2)return null;
  return make('公開本文では省略されていますが、第190条の券面図は改正公告のPDFで確認できます。',[
   {heading:'公開本文の省略',body:'第5章の公開PDFでは第190条の本文・図が省略され、見出しが掲載されています。省略を、条文の削除や様式の不存在とは扱いません。',source_ids:[base.id]},
   {heading:'保存した改正公告の図を開く',body:'2026年3月14日施行分の改正公告のPDF74ページに着駅準常備式、75ページに発駅準常備式の券面図があります。新旧対照表の「改正」欄を確認してください。図の細かな文字は検索用テキストに含まれていないため、下の出典からPDFの画像を開いて確認できます。',source_ids:figures.map(s=>s.id)},
   {heading:'補完できる範囲',body:'この図の掲載だけで、省略された章全体や、その後の全改正を反映した現行全文まで確定できるわけではありません。',source_ids:[base.id,...figures.map(s=>s.id)]}
  ],[base,...figures]);
 }
 if(/猫|小犬|ペット|小動物/.test(question)&&!/補助犬|盲導犬|介助犬|聴導犬/.test(question)){
  const s=article('第309条'),t=article('第308条'),u=article('第310条');if(!s||!t||!u)return null;
  return make('猫などの小動物は、専用容器・大きさ・重量などの条件を満たし、会社の承諾と料金の支払いを受けて持ち込めます。',[
   {heading:'容器と重量などの条件',body:'第309条では、他の旅客への危害・迷惑のおそれがない小犬・猫・はと等の小動物を、3辺の最大の和が120cm以内の専用容器に収納し、容器に収納した総重量を10kg以内とする条件を定めています。猛獣・へびの類は除かれます。持込区間・持込日等の申し出と、会社の承諾も必要です。',source_ids:[s.id]},
   {heading:'料金・個数と切符',body:'収録版の普通手回り品料金は、1回の乗車につき1個290円です。第308条第1項の制限内での持ち込みであり、同項には2個まで等の制限があります。料金を支払うと、普通手回り品切符またはこれに代わる証票が交付されます。',source_ids:[s.id,t.id,u.id]}
  ],[s,t,u]);
 }
 if(/有効期間|有効日数/.test(question)&&!/変更|延長|定期|回数/.test(question)){
  const s=article('第154条');if(!s)return null;
  return make('普通乗車券の有効期間は、営業キロを基準に決まり、近郊区間などの例外があります。',[
   {heading:'普通乗車券の基本日数',body:'営業キロ100kmまでは1日、100kmを超え200kmまでは2日です。200kmを超えると、200kmまで増すごとに1日を加えます。たとえば201〜400kmは3日です。',source_ids:[s.id]},
   {heading:'例外と距離の確認',body:'第156条第2号の大都市近郊区間内相互発着の乗車券は、近郊区間の外を経る場合を除いて1日です。運賃計算に特例がある場合等の営業キロの扱いは、第154条第2項・第3項も確認します。',source_ids:[s.id]}
  ],[s],['具体的な日数の確認には、きっぷの種類、発着駅・経路、営業キロが必要です。']);
 }
 if(/払(?:い)?戻|払いもど|キャンセル/.test(question)&&/使用前|使う前|旅行開始前|未使用/.test(question)&&!/特急|急行|指定席|グリーン|寝台|定期|回数/.test(question)){
  const s=article('第271条');if(!s)return null;
  return make('旅行開始前の普通乗車券は、入鋏前・有効期間内などの条件を満たせば払いもどしを請求できます。収録版の手数料は1枚220円です。',[
   {heading:'普通乗車券の条件と手数料',body:'第271条第1項は、旅行開始前で、乗車券が入鋏前かつ有効期間内であることを条件としています。前売りの乗車券は有効期間開始日前も含みます。駅に差し出して支払済み運賃の払いもどしを請求し、1枚につき220円の手数料を支払う規定です。',source_ids:[s.id]},
   {heading:'指定券と関連する場合',body:'第64条の証明をした普通乗車券については、第271条第2項の追加条件があります。特急券等の料金の払いもどしや、使用後の扱いをこの一般案内だけで確定しないでください。',source_ids:[s.id]}
  ],[s],['乗車券と特急券等の内訳、有効期間、使用状況を確認してください。']);
 }
 return null;
}
