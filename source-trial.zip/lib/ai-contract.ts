export type AnswerPlan={taskId:string;system:string;payload:Record<string,unknown>;schema:Record<string,unknown>};
