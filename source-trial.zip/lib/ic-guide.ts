import type {Answer,Source,Company} from './rail';
import {icQuestion} from './source-scope';
const north='小樽 南小樽 小樽築港 朝里 銭函 ほしみ 星置 稲穂 手稲 稲積公園 発寒 発寒中央 琴似 桑園 札幌 苗穂 白石 厚別 森林公園 大麻 野幌 高砂 江別 豊幌 幌向 上幌向 岩見沢 峰延 光珠内 美唄 茶志内 奈井江 豊沼 砂川 滝川 江部乙 妹背牛 深川 納内 近文 旭川 八軒 新川 新琴似 太平 百合が原 篠路 拓北 あいの里教育大 あいの里公園 ロイズタウン 太美 当別 北海道医療大学 平和 新札幌 上野幌 北広島 島松 恵み野 恵庭 サッポロビール庭園 長都 千歳 南千歳 植苗 沼ノ端 新千歳空港 苫小牧'.split(' ');
const south='函館 五稜郭 桔梗 大中山 七飯 新函館北斗'.split(' ');
const outside='長万部 余市 倶知安 白老 登別 幌別 鷲別 東室蘭 室蘭 伊達紋別 洞爺 美瑛 美馬牛 上富良野 中富良野 富良野 帯広 釧路'.split(' ');
const all=[...north,...south,...outside].sort((a,b)=>b.length-a.length);
function stationNames(q:string){const found:string[]=[];let text=q;for(const s of all)if(text.includes(s)){found.push(s);text=text.replaceAll(s,'□');}return found.sort((a,b)=>q.indexOf(a)-q.indexOf(b));}
export function icAreaGuide(question:string,company:Company,date:string,sources:Source[]):Answer|null{
 if(company!=='hokkaido'||!icQuestion(question)||date<'2026-11-21'||date>='2028-01-01')return null;
 const q=question.normalize('NFKC');
 if(q.length>100||/\d|定期|子ども|小児|幼児|障害|障がい|割引|ポイント|チャージ|払[い]?戻|再発行|紛失|変更|電子マネー|買[い]?物|入場|特急|新幹線|指定席|指定券|uシート|u-seat|グリーン|寝台|特別車両|経由|途中|エリア外|エリアを出|乗り越|乗越|将来|今後|拡大|クレジット|デビット|WAON|nanaco|地下鉄|市電|バス|私鉄|いさりび|残高|残額|不足|足り|足ら|空っぽ|ゼロ|無料|無賃|借り|貸し|名義|他人|家族|親|友達|記名|故障|壊|タッチ|改札機|違い|比較|使い分け|どっち|どちら/i.test(q))return null;
 const area=/どこ|範囲|エリア|使える駅|利用できる駅|対応駅|使え|利用|乗れ/.test(q);if(!area)return null;
 const table=sources.find(s=>s.article==='IC別表2'),rules=sources.find(s=>s.article==='IC第22条'),guide=sources.find(s=>s.article==='Kitaca 利用可能エリア'),suica=sources.find(s=>s.article==='Suica 北海道エリアの利用案内');if(!table||!rules||!guide||!suica)return null;
 const assumptions=['2026年11月21日に確認した公式資料に基づきます。2028年春予定の拡大は現在の利用範囲に含めていません。'];
 let summary:string,sections:Answer['sections'];
 if(/sapica|サピカ/i.test(q)){
  if(!/JR|ＪＲ|列車|鉄道|Kitaca|キタカ/i.test(q))return null;
  summary='SAPICAはJR北海道のKitacaエリアでは使えません。';sections=[{heading:'カードの種類による違い',body:'JR北海道は、KitacaエリアでSuica・PASMOなどの相互利用カードを利用できる一方、SAPICAは利用できないと案内しています。交通系ICカードでも、すべて同じ範囲で使えるわけではありません。',source_ids:[guide.id]}];
 }else{
  const stations=stationNames(q);
  if(stations.length===2&&/から|→|まで|間|発|着/.test(q)){
   const [a,b]=stations,one=north.includes(a)?'north':south.includes(a)?'south':'outside',two=north.includes(b)?'north':south.includes(b)?'south':'outside';
   const ok=one===two&&one!=='outside';summary=a+'・'+b+'間は、'+(ok?'Kitaca・Suicaなどの相互利用カードで乗車できます。':'Kitaca・SuicaなどのICカードだけでは乗車できません。');
   sections=[{heading:'利用できる区間の確認',body:ok?'両駅は同じKitacaエリア内です。そのエリア内で完結する乗車が対象です。別のエリアやエリア外を経由する乗車は含みません。':one!==two&&one!=='outside'&&two!=='outside'?'札幌・旭川エリアと函館エリアは別のエリアです。両エリアをまたぐ乗車には利用できないため、あらかじめ全区間のきっぷを購入してください。':'ご指定の駅には現在のKitacaエリア外の駅が含まれます。あらかじめ全区間のきっぷを購入してください。',source_ids:[table.id,rules.id]}];
  }else if(stations.length>0)return null;
  else{
   summary='交通系ICカードは北海道全域で使えるわけではありません。JRでは「札幌・旭川エリア」と「函館エリア」の中で利用できます。';
   sections=[{heading:'JR北海道で使える範囲',body:'札幌・旭川エリアは、函館本線の小樽〜旭川、札沼線の桑園〜北海道医療大学、千歳線の白石〜沼ノ端・南千歳〜新千歳空港、室蘭本線の沼ノ端〜苫小牧です。函館エリアは函館〜新函館北斗です。札幌・旭川エリアと函館エリアをまたぐ乗車や、エリア外への乗り越しには利用できません。',source_ids:[table.id,rules.id]},{heading:'Suicaなどの他社カード・JR以外の交通',body:'KitacaエリアではSuica・PASMO・ICOCAなどの相互利用カードも使えます。SAPICAはJRでは使えません。Suicaは、札幌のSAPICAエリアや函館のICAS nimocaエリアでも利用できます。JR、地下鉄、バスなどでは対応区間が異なるため、使うカードと交通機関を分けて確認してください。',source_ids:[guide.id,suica.id]}];
  }
 }
 const ids=new Set(sections.flatMap(s=>s.source_ids));return{id:crypto.randomUUID(),question,company,journeyDate:date,summary,sections,sources:sources.filter(s=>ids.has(s.id)),assumptions,followup:[],mode:'reference',confidence:'conditional',notice:'公式の利用エリアと取扱規則を照合した案内です。'};
}
