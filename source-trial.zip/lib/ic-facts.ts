import type {Answer,Company,Source} from './rail';
// Source-reviewed rules cover new values and wording without answer-cache hits.
// Extra/unsupported conditions always return to the full reader.
export function icFactGuide(question:string,company:Company,date:string,sources:Source[]):Answer|null{
 const q=question.normalize('NFKC');if(company!=='hokkaido'||date<'2026-11-21'||date>='2028-01-01'||!/kitaca|キタカ/i.test(q)||/suica|pasmo|sapica|icoca|nimoca|発行|発売|購入|郵送|使い方|使用方法|経路|無効|不正|失効|障がい|障害|子ども|小児|幼児|割引|モバイル|他人|他社|新幹線|特急|指定席|uシート|グリーン|寝台|クレジット|デビット|カード払い|硬貨|外国|海外|ポイント|なぜ|理由|どうして|予定|将来|改正|矛盾|取消|返却しない|返さず|返したく|残したい|カードを残|SFだけ/i.test(q))return null;
 const by=(article:string)=>sources.find(s=>s.article===article);let summary='',heading='',body='',needed:string[]=[],conditions:string[]=[];
 const amounts=[...q.matchAll(/(\d[\d,]*)\s*円/g)],allDigits=[...q.matchAll(/\d[\d,]*/g)];
 if(/払[い]?戻|払いもど/.test(q)&&/残[高額]|SF/i.test(q)&&amounts.length===1&&allDigits.length===1&&!/定期|再発行|紛失|デポジット|預り金|除く|だけ|のみ/.test(q)){
  const amount=Number(amounts[0][1].replaceAll(',',''));if(!Number.isSafeInteger(amount)||amount<0||amount>20000||amount%10!==0)return null;
  const fee=Math.min(220,amount),refund=amount-fee+500;summary='定期券を付けていないKitacaを返却する場合、受取額は'+refund.toLocaleString('ja-JP')+'円です。';heading='残額と手数料・預り金の計算';body='SF残額'+amount.toLocaleString('ja-JP')+'円から手数料'+fee+'円を引き、デポジット500円を加えます。計算は '+amount.toLocaleString('ja-JP')+' − '+fee+' ＋ 500 ＝ '+refund.toLocaleString('ja-JP')+'円です。手数料は通常220円ですが、SF残額が220円未満の場合はその残額です。記名式の場合は、本人確認の手続きも必要です。';needed=['IC第15条','IC第10条'];conditions=['定期券を付けていないKitacaを正規に返却する場合の計算です。定期券付きのカードは定期券部分を含む別計算になります。'];
 }else if(allDigits.length)return null;
 else if(/デポジット|預[りか]?金|預り金/.test(q)&&/返[却金還]|戻|払[い]?戻/.test(q)&&!/定期|紛失|再発行|なく|落と|使[わっ]|充当/.test(q)){
  summary='Kitacaを正規に返却する場合、デポジット500円も返却されます。';heading='残額の払戻しとデポジット';body='ICカード乗車券取扱規則第10条は、カードを返却したときにデポジットを返却すると定めています。ただし、第11条・第29条・第30条・第31条に定める場合は除かれます。SF残額の払戻し手数料は別に計算するため、残額とデポジットは分けて確認します。';needed=['IC第10条','IC第15条'];
 }else if(/チャージ|入金/.test(q)&&/上限|いくらまで|最大|限度/.test(q)&&!/定期|払い|払戻|残額が|残高が|入れて|入って/.test(q)){
  summary='Kitacaのチャージ残額の上限は、1枚につき20,000円です。';heading='残額の上限と1回のチャージ額';body='ICカード乗車券取扱規則第12条により、1枚のSF残額は20,000円を超えられません。1回のチャージ額は、別表1の1,000円・2,000円・3,000円・4,000円・5,000円・10,000円のいずれかです。一部のチャージ機では4,000円のチャージを扱いません。';needed=['IC第12条','IC別表1'];
 }else if(/入場券/.test(q)&&/使|利用|入れ|代わり|替わり/.test(q)&&!/定期|払|精算|同じ駅/.test(q)){
  summary='Kitacaを入場券として使うことはできません。';heading='駅の入場だけに利用する場合';body='JR北海道の公式FAQでは、Kitacaエリア内の駅でKitacaを入場券として利用することはできないと案内しています。列車に乗るための利用と、見送りなどの入場券としての利用は別の取扱いです。';needed=['Kitaca 入場券としての利用'];
 }else if(/途中下車/.test(q)&&!/定期|特急|精算|金額|いくら|改めて|乗り直|払い/.test(q)){
  summary='Kitacaでの乗車は、途中下車の取扱いをしません。';heading='片道1回の乗車としての効力';body='ICカード乗車券取扱規則第28条は、当該乗車区間について片道乗車1回に限り有効とし、途中下車の取扱いをしないと定めています。紙の普通乗車券で認められる途中下車の条件を、そのままKitacaに適用することはできません。';needed=['IC第28条'];
 }
 if(!summary)return null;const selected=needed.map(by);if(selected.some(s=>!s))return null;
 return{id:crypto.randomUUID(),question,company,journeyDate:date,summary,sections:[{heading,body,source_ids:selected.map(s=>s!.id)}],sources:selected as Source[],assumptions:[...conditions,'2026年11月21日に確認した公式資料に基づきます。公開PDFの改正履歴・利用日への適用も原文で確認してください。'],followup:[],confidence:'conditional',mode:'reference',notice:'公式規則に照合した条件と計算結果です。'};
}
