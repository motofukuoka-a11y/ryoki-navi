import index from '../data/semantic-index.json';
import corpus from '../data/corpus.json';
import type {Company,Source} from './rail';
import {retrieve} from './rail';
import {icQuestion,icSource,authoritative,availableSource} from './source-scope';
const sources=new Map((corpus.chunks as Source[]).map(s=>[s.id,s]));
const vectors=index.rows.map(row=>{const binary=atob(row.bytes);return {source:sources.get(row.id)!,norm:row.norm,vector:Int8Array.from(binary,c=>c.charCodeAt(0))};});
export const embeddingModel='@cf/baai/bge-m3';
export function semanticArticles(query:string,embedding:unknown,company:Company,date:string){
 if(!Array.isArray(embedding)||embedding.length!==index.dimension||!embedding.every(x=>typeof x==='number'&&Number.isFinite(x)))throw new Error('Invalid search embedding');
 const ranked=vectors.filter(row=>row.source.company===company&&availableSource(row.source,date)&&(icQuestion(query)?icSource(row.source):!icSource(row.source))).map(row=>{let dot=0;for(let i=0;i<embedding.length;i++)dot+=embedding[i]*row.vector[i];return {source:row.source,score:dot/row.norm};}).sort((a,b)=>b.score-a.score);
 const semantic=[...new Set(ranked.slice(0,16).map(x=>x.source.article))];
 const lexical=[...new Set(retrieve(query,company,date,12).filter(authoritative).map(s=>s.article))];
 const fused=new Map<string,number>();
 for(const list of [semantic,lexical])list.forEach((article,i)=>fused.set(article,(fused.get(article)??0)+1/(20+i)));
 return [...fused].sort((a,b)=>b[1]-a[1]).slice(0,6).map(([article])=>article);
}
