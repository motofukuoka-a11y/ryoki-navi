import corpus from '../data/corpus.json';
import {retrieve,type Source,type Company} from './rail';

const chunks=corpus.chunks as Source[];
export const articleNumbers=(s:string)=>[...new Set([...s.normalize('NFKC').matchAll(/第\s*(\d+)\s*条(?:\s*の\s*(\d+))?/g)].map(m=>'第'+m[1]+'条'+(m[2]?'の'+m[2]:'')))];
const official=chunks.filter(s=>s.evidence==='official_text');
const eligible=(s:Source,company:Company,date:string)=>s.company===company&&(!s.effectiveFrom||s.effectiveFrom<=date);
export type SearchSelection={resolvedQuestion:string;articles:string[];queries:string[]};
export function collectEvidence(query:string,company:Company,date:string,selected:SearchSelection,strict=false):Source[]{
 const explicit=articleNumbers(query),anchors=retrieve(query,company,date,4).filter(s=>s.evidence==='official_text').map(s=>s.article),primary=[...new Set([...explicit,...(strict?[]:anchors),...selected.articles])].slice(0,8);
 const sources:Source[]=[];const add=(s:Source)=>{if(!sources.some(t=>t.id===s.id)&&eligible(s,company,date)&&s.evidence!=='editorial_note')sources.push(s);};
 // Preserve every part of a named article. The general search deduplicates titles,
 // which used to silently discard later parts of long articles.
 for(const article of primary)official.filter(s=>eligible(s,company,date)&&s.article===article).forEach(add);
 if(!strict){
  const seed=sources.slice(0,5);
  const refs=[...new Set(seed.flatMap(s=>articleNumbers(s.text)))].filter(a=>!primary.includes(a));
  for(const article of refs.slice(0,3))official.filter(s=>eligible(s,company,date)&&s.article===article).forEach(add);
  // Amendment pages are supporting evidence, never silently merged into base text.
  const amends=chunks.filter(s=>s.evidence==='amendment'&&eligible(s,company,date)&&articleNumbers(s.article).some(a=>primary.includes(a))).sort((a,b)=>b.effectiveFrom.localeCompare(a.effectiveFrom));
  amends.slice(0,2).forEach(add);
 }
 // Keep selected articles ahead of incidental lexical matches, while reserving
 // room for applicable amendment pages.
 const amendments=sources.filter(s=>s.evidence==='amendment').slice(0,2);
 return [...sources.filter(s=>s.evidence!=='amendment').slice(0,10-amendments.length),...amendments];
}
export function matchingArticleParts(query:string,company:Company,date:string){const wanted=articleNumbers(query);return official.filter(s=>wanted.includes(s.article)&&eligible(s,company,date));}
