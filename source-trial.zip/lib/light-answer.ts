import corpus from '../data/corpus.json';
import {scopedArticles,availableSource} from './source-scope';
import {resolvedQuestion} from './question-intent';
import {referenceAnswer} from './reference';
import {searchAnswer,type Answer,type Company,type Source} from './rail';

export type LightRequest={question:string;company:Company;journeyDate:string;history:{role:string;content:string}[];guideEnabled:boolean};
const chunks=corpus.chunks as Source[];
function plain(question:string,company:Company,date:string,summary:string,notice:string):Answer{
 return{id:crypto.randomUUID(),question,company,journeyDate:date,mode:'search',confidence:'insufficient',summary,notice,sections:[],sources:[],followup:[],assumptions:[]};
}
export function answerLight(input:LightRequest):Answer{
 const {company,journeyDate,guideEnabled}=input;
 const question=input.question.trim();
 if(!question||question.length>2500||!['hokkaido','east','both'].includes(company)||!/^\d{4}-\d{2}-\d{2}$/.test(journeyDate))throw new Error('質問・対象会社・利用日を確認してください。');
 const query=resolvedQuestion(question,input.history);
 if(company!=='hokkaido'||/JR東日本|ＪＲ東日本/.test(query))return plain(question,company,journeyDate,'JR東日本の規則は、この版には未収録です。','北海道の資料で代用せず、取扱いを確定しません。');
 if(/企画乗車券|フリーきっぷ|おトクなきっぷ|青春18|えきねっと|トクだ値/i.test(query))return plain(question,company,journeyDate,'このきっぷ・サービス固有の規則は未収録です。','対象サービスの公式案内を確認してください。');
 if(/^(こんにちは|こんばんは|おはようございます|おはよう|ありがとう(?:ございます)?)[。！!\s]*$/.test(question))return plain(question,company,journeyDate,'きっぷの種類や区間、確認したい条件を添えて質問してください。','条文検索と、原文に照合した基本案内を利用できます。');
 const articles=scopedArticles(query,[...new Set([...query.normalize('NFKC').matchAll(/第\s*(\d+)\s*条(?:\s*の\s*(\d+))?/g)].map(m=>'第'+m[1]+'条'+(m[2]?'の'+m[2]:'')))]);
 // Explicit article requests stay on those articles, even when other search terms match better.
 // The reviewed article 190 figure guide intentionally includes its official amendment diagrams.
 if(guideEnabled&&articles.length===1&&articles[0]==='第190条'&&/様式|券面|図|省略|準常備/.test(query)){
  const guide=referenceAnswer(query,company,journeyDate);if(guide)return{...guide,question};
 }
 if(articles.length){
  const sources=chunks.filter(s=>s.company===company&&s.evidence==='official_text'&&articles.includes(s.article)&&availableSource(s,journeyDate));
  const selected=[...new Map(sources.map(s=>[s.article,s])).values()].slice(0,6);
  const missing=articles.filter(a=>!sources.some(s=>s.article===a));
  if(!selected.length)return plain(question,company,journeyDate,articles.join('・')+'は収録資料から確認できませんでした。','条番号・対象会社・利用日、資料の収録範囲を確認してください。');
  const result:Answer={id:crypto.randomUUID(),question,company,journeyDate,mode:'search',confidence:'insufficient',summary:selected.map(s=>s.article).join('・')+'の収録原文を表示します。',sections:selected.map(s=>({heading:s.title,body:s.text.replace(/\s+/g,' ').slice(0,650)+(s.text.length>650?'…':''),source_ids:[s.id]})),sources:selected,notice:'指定された条文の抜粋です。個別条件への当てはめや、未収録部分の補完は行っていません。',assumptions:['公開資料には省略と未統合の改正があり、利用日への適用は原文と改正公告で確認が必要です。'],followup:missing.length?[missing.join('・')+'は収録資料から確認できませんでした。']:[]};
  return result;
 }
 if(guideEnabled){const guide=referenceAnswer(query,company,journeyDate);if(guide)return{...guide,question};}
 return{...searchAnswer(query,company,journeyDate,'関連する公開資料の抜粋です。案内として整備していない質問には、検索結果を表示します。'),question};
}
