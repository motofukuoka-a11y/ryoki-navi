import type {Answer,Company} from './rail';

export type Catalog={snapshotDate:string;chunks:number;documents:{title:string;url:string;localUrl:string;company:string;pages:number}[]};
export type QuestionInput={question:string;company:Company;journeyDate:string;history:{role:string;content:string}[];aiEnabled:boolean;shareAnswer?:boolean;semanticReuse?:boolean;chatId?:string;requestId?:string};
export type ChatRecord={id:string;title:string;updated:number;answers:Answer[];loaded?:boolean;olderCursor?:number};
export type Progress={type:'reset'}|{type:'status';message:string}|{type:'comparison';comparison:NonNullable<Answer['delivery']>['comparison']}|{type:'preview';answer:Answer};
const base=(import.meta.env.VITE_API_BASE||'').replace(/\/$/,'');

export async function fetchBootstrap():Promise<{catalog:Catalog;aiReady:boolean;historyReady?:boolean;model?:string;version?:string}>{
 const response=await fetch(base+'/api/bootstrap',{cache:'no-store',credentials:'same-origin',signal:AbortSignal.timeout(15000)});
 if(!response.ok)throw new Error('接続できませんでした。時間をおいてお試しください。');
 return response.json();
}

export async function requestAnswer(input:QuestionInput,signal:AbortSignal,onProgress:(event:Progress)=>void=()=>{}):Promise<Answer>{
 const response=await fetch(base+'/api/answer',{method:'POST',headers:{'Content-Type':'application/json',Accept:'application/x-ndjson'},credentials:'same-origin',cache:'no-store',body:JSON.stringify(input),signal:AbortSignal.any([signal,AbortSignal.timeout(240000)])});
 if(!response.ok)throw new Error('回答を取得できませんでした。時間をおいて再試行してください。');
 if(!response.headers.get('Content-Type')?.includes('application/x-ndjson'))return response.json();
 const reader=response.body?.getReader();if(!reader)throw new Error('回答を読み取れませんでした。');
 const decoder=new TextDecoder();let buffer='',answer:Answer|undefined;
 try{for(;;){const {done,value}=await reader.read();buffer+=decoder.decode(value,{stream:!done});if(buffer.length>2000000)throw new Error('回答が長すぎます。');let split;while((split=buffer.indexOf('\n'))>=0){const line=buffer.slice(0,split);buffer=buffer.slice(split+1);if(!line.trim())continue;const event=JSON.parse(line);if(event.type==='answer')answer=event.answer;else if(event.type==='error')throw new Error(event.message);else if(event.type==='reset'||event.type==='status'||event.type==='comparison'||event.type==='preview')onProgress(event);}if(done)break;}}
 finally{reader.releaseLock();}
 if(!answer)throw new Error('回答が途中で切れました。再試行してください。');return answer;
}
async function historyRequest(path='',method='GET'){
 const response=await fetch(base+'/api/history'+path,{method,credentials:'same-origin',cache:'no-store',signal:AbortSignal.timeout(20000)});
 if(!response.ok)throw new Error('サーバの履歴に接続できません。再試行してください。');return response.json();
}
export async function fetchHistory(offset=0):Promise<{chats:ChatRecord[];hasMore:boolean}>{const data=await historyRequest('?offset='+offset);return{chats:data.chats.map((c:Omit<ChatRecord,'answers'>)=>({...c,answers:[],loaded:false})),hasMore:data.hasMore};}
export async function fetchChat(id:string,before?:number):Promise<ChatRecord>{const data=await historyRequest('/'+id+(before?'?before='+before:''));return{...data,loaded:true};}
export async function removeHistory(id?:string){await historyRequest(id?'/'+id:'','DELETE');}
