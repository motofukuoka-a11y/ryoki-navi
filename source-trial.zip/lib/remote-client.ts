import type {Answer,Company} from './rail';

export type Catalog={snapshotDate:string;chunks:number;documents:{title:string;url:string;localUrl:string;company:string;pages:number}[]};
export type QuestionInput={question:string;company:Company;journeyDate:string;history:{role:string;content:string}[];aiEnabled:boolean};
const base=(import.meta.env.VITE_API_BASE||'').replace(/\/$/,'');

export async function fetchBootstrap():Promise<{catalog:Catalog;aiReady:boolean}>{
 const response=await fetch(base+'/api/bootstrap',{cache:'no-store',credentials:'omit',signal:AbortSignal.timeout(15000)});
 if(!response.ok)throw new Error('サーバーに接続できませんでした。時間をおいて再確認してください。');
 return response.json();
}

export async function requestAnswer(input:QuestionInput,signal:AbortSignal):Promise<Answer>{
 const response=await fetch(base+'/api/answer',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'omit',cache:'no-store',body:JSON.stringify(input),signal:AbortSignal.any([signal,AbortSignal.timeout(150000)])});
 if(!response.ok)throw new Error('回答を取得できませんでした。時間をおいて再試行してください。');
 return response.json();
}
