import type {Answer,Company} from './rail';
export type Turn={role:string;content:string};
const normalized=(q:string)=>q.normalize('NFKC').replace(/\s+/g,'').replace(/[?？。!！]+$/,'');
const usage=/^(?:この|その)?(?:アプリ|サイト|旅規ナビ)?(?:の)?(?:使い方|使用方法|利用方法)(?:は|を教えて(?:ください|下さい)?)?$/;
export function bareUsage(q:string){return usage.test(normalized(q))||/^(?:この|その)?(?:アプリ|サイト|旅規ナビ)(?:は|って|を)?(?:どう|どのように)(?:使う|利用する|使え|使います)(?:の|か|んですか|のですか)?$/.test(normalized(q));}
export function contextNeeded(q:string,previous?:Answer|null,explicit=false){
 if(!previous)return false;
 if(explicit||previous.mode==='clarification'||bareUsage(q))return true;
 if(previous.followup.length&&/^(はい|いいえ|普通乗車券|普通のきっぷ|紙の(?:きっぷ|乗車券)|定期券|特急券|未使用|使用(?:開始)?(?:前|後)|旅行開始(?:前|後)|乗車(?:前|後)|一体型|通常のKitaca)/i.test(q))return true;
 return /^(それ|その|では|じゃ|同じ条件|この場合|今の|なぜ|どうして|つまり|いくら|何日|何円|手数料は|有効日数は|普通乗車券なら|普通のきっぷなら|使用(?:開始)?(?:前|後)|旅行開始(?:前|後)|乗車(?:前|後)|道外(?:なら|では)|通常の|一体型|記名式|無記名式)/.test(q);
}
export function conversationHistory(turns:Turn[]):Turn[]{
 const conditions=turns.filter(t=>t.role==='user').map(t=>t.content).join('\n追加条件: ');
 if(conditions.length>6000)throw new Error('これまでの条件が長くなっています。「新しい質問」から、現在の条件をまとめて入力してください。');
 const last=turns.filter(t=>t.role==='assistant').at(-1);
 return conditions?[{role:'user',content:conditions},...(last?[{role:'assistant',content:last.content.slice(0,800)}]:[])]:[];
}
export function resolvedQuestion(q:string,history:Turn[]){
 const users=history.filter(m=>m.role==='user').map(m=>m.content);
 // The supplied chain is active context, not other visitors' saved questions.
 return users.length?users.join('\n')+'\n追加・訂正条件: '+q:q;
}
export function retrievalQuery(q:string){
 return q.normalize('NFKC').replace(/キタカ/gi,'Kitaca').replace(/発行|買いたい|買える|購入/g,'発売 購入').replace(/払い戻|払戻/g,'払いもどし').replace(/ルート/g,'経路');
}
export function intentArticles(q:string){
 const latest=q.split('追加・訂正条件: ').at(-1)!;
 if(/Kitaca|キタカ/i.test(q)&&!/旅客営業規則|普通乗車券|紙のきっぷ/.test(latest)){
  if(/使い方|使用方法|利用方法|使う方法/.test(latest))return ['IC第21条','IC第22条'];
  if(/再発行|紛失|なくした/.test(latest))return ['IC第16条','IC第17条'];
  if(/払[い]?戻|払いもど|返金/.test(latest))return ['IC第15条','IC第32条'];
  if(/チャージ|入金/.test(latest))return ['IC第12条'];
  if(/利用エリア|どこまで|使え|乗れ/.test(latest))return ['IC第22条','IC別表2'];
 }
 if(/Kitaca|キタカ/i.test(q)&&!/旅客営業規則|普通乗車券|紙のきっぷ/.test(latest)&&/発行|発売|購入|買え|買い|買う|欲し|郵送|作れ|作る|申し込/.test(q))return ['IC第5条'];
 if(/経路|ルート|山線|海線/.test(q)&&/変え|変更|差額|戻/.test(q))return /運休|不通|運行不能|災害|代行/.test(q)?['第282条','第285条','第289条']:['第248条','第249条','第243条'];
 if(/目次|何条|何章|全体.*構成|規則.*構成|最終.*条|最後.*条/.test(q))return /IC|Kitaca|キタカ/i.test(q)?['IC規則の構成']:['旅客営業規則の構成'];
 return [];
}
export function assistance(q:string,company:Company,date:string,history:Turn[]):Answer|null{
 const n=normalized(q),make=(summary:string,body:string,followup:string[]=[],clarify=false):Answer=>({id:crypto.randomUUID(),question:q,company,journeyDate:date,summary,sections:body?[{heading:clarify?'確認したいこと':'ご利用方法',body,source_ids:[]}]:[],mode:clarify?'clarification':'help',confidence:'conditional',followup,assumptions:[],sources:[],notice:''});
 if(bareUsage(q)){
  if(/アプリ|サイト|旅規ナビ/.test(n))return make('質問欄に疑問を入力し、「質問する」を押してください。','きっぷの種類、区間、使用前・使用後など、分かる条件を添えてください。Enterは改行です。回答の下から出典と原文を確認でき、「続けて質問」で条件を追加できます。');
  if(!history.length)return make('何の使い方を知りたいですか？','このアプリの操作か、ICカード・きっぷの使い方かを教えてください。',['このアプリの使い方','Kitacaの使い方'],true);
  if(history.some(m=>m.role==='user'&&bareUsage(m.content))&&!history.some(m=>m.role==='user'&&/Kitaca|キタカ|ICカード|乗車券|定期券/i.test(m.content)))return make('このアプリと、ICカード・きっぷのどちらについてですか？','対象が分かれば、その使い方を案内します。',[],true);
 }
 if(/^(こんにちは|こんばんは|おはよう(?:ございます)?|ありがとう(?:ございます)?|なにしていますか|何をしていますか|何していますか|何ができ(?:る|ますか)|あなたは誰|使える機能)(?:ね|の)?$/.test(n))return make('鉄道やきっぷの疑問を、公式資料をもとに調べます。','JR北海道の乗車券、払い戻し、ICカードなどについて質問できます。条件が足りない場合は確認し、回答には根拠となる資料を表示します。');
 if(/(?:このアプリ|旅規ナビ|あなた).*(?:学習|ディープラーニング)|^(?:学習|ディープラーニング)(?:していますか|できるの|できていますか)$/.test(n))return make('事前に深層学習で訓練されたAIが、公式資料を読んで回答します。','質問履歴は条件の照合と回答の再利用に使います。保存するだけでモデルの重みが追加学習される仕組みではありません。規則資料と回答処理は、確認した問題に応じて更新します。');
 return null;
}
