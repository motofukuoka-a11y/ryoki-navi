import revision from '../data/cache-version.json';
import type {Answer} from '../lib/rail';
import {type Database,type StoredInput,requestKey,checkedCache} from './storage';
import {quickGuide} from '../lib/quick-guide';

// Sharing is explicit on each request. Old clients that omit it remain private.
// Shared entries never contain a visitor identifier, chat ID or prior conversation.
export function sharingStatus(input:StoredInput):'enabled'|'off'|'conversation'|'sensitive'|'unsupported'{
 if(!input.shareAnswer)return 'off';
 if(input.history.length)return 'conversation';
 if(input.company!=='hokkaido'||!input.aiEnabled)return 'unsupported';
 if(/JR(?:東海|西日本|四国|九州)|企画乗車券|フリーきっぷ|おトクなきっぷ|青春18|えきねっと|トクだ値/i.test(input.question))return 'unsupported';
 const q=input.question.normalize('NFKC');
 if(/氏名|姓名|名前|住所|電話番号|メールアドレス|生年月日|社員番号|社員ID|顧客番号|パスワード|暗証|口座|カード番号|社外秘|秘密|診断|病名|手帳番号/i.test(q)||/[\w.+-]+@[\w.-]+\.[a-z]{2,}/i.test(q)||/(?:\d[ -]?){10,}/.test(q))return 'sensitive';
 return 'enabled';
}
const signature=(a:Answer)=>JSON.stringify({summary:a.summary,sections:a.sections,sources:a.sources,confidence:a.confidence,followup:a.followup,assumptions:a.assumptions,mode:a.mode,notice:a.notice,company:a.company,journeyDate:a.journeyDate});
export function checkedSharedAnswer(value:string):Answer|null{
 try{
  const record=JSON.parse(value) as Answer&{cache_review_question?:unknown};const question=record.cache_review_question;delete record.cache_review_question;
  if(record.mode==='ai')return checkedCache(JSON.stringify(record));
  if(record.mode!=='reference'||typeof question!=='string'||!record.sources.length)return null;
  const expected=quickGuide(question,record.company,record.journeyDate,[]);
  return expected&&signature(expected)===signature(record)?record:null;
 }catch{return null;}
}
export async function sharedAnswer(db:Database,input:StoredInput){
 if(sharingStatus(input)!=='enabled')return null;
 const key=requestKey(input);
 const row=await db.prepare('SELECT answer_json,created,request_key AS canonical_key,NULL AS checks_json,0 AS priority FROM shared_answers WHERE request_key=? AND revision=? UNION ALL SELECT s.answer_json,s.created,a.canonical_key,a.checks_json,1 AS priority FROM shared_aliases a JOIN shared_answers s ON s.request_key=a.canonical_key AND s.revision=a.revision WHERE a.request_key=? AND a.revision=? ORDER BY priority LIMIT 1').bind(key,revision.sha256,key,revision.sha256).first<{answer_json:string;created:number;canonical_key:string;checks_json:string|null}>();
 if(!row)return null;
 const answer=checkedSharedAnswer(row.answer_json);
 if(!answer||answer.company!==input.company||answer.journeyDate!==input.journeyDate)return null;
 let matchChecks: {label:string;value:string}[]|undefined;
 if(row.checks_json)try{const checks=JSON.parse(row.checks_json);if(!Array.isArray(checks)||checks.length>10||checks.some(c=>!c||typeof c.label!=='string'||typeof c.value!=='string'||c.label.length>60||c.value.length>600))return null;matchChecks=checks;}catch{return null;}
 return{answer:{...answer,id:crypto.randomUUID(),question:input.question},generatedAt:row.created,canonicalKey:row.canonical_key,matchType:row.checks_json?'semantic' as const:'exact' as const,matchChecks};
}
export async function saveSharedAnswer(db:Database,input:StoredInput,answer:Answer){
 if(sharingStatus(input)!=='enabled')return false;
 // Do not copy A's history, request/answer identifiers or private comparison into B's response.
 const clean={...answer,id:'',question:'',...(answer.mode==='reference'?{cache_review_question:input.question}:{})};delete clean.delivery;delete clean.diagnostics;
 if(!checkedSharedAnswer(JSON.stringify(clean)))return false;
 await db.batch([
  db.prepare('INSERT INTO shared_answers(request_key,revision,answer_json,created) VALUES(?,?,?,?) ON CONFLICT(request_key) DO UPDATE SET answer_json=excluded.answer_json,created=excluded.created,revision=excluded.revision').bind(requestKey(input),revision.sha256,JSON.stringify(clean),answer.delivery?.generatedAt??Date.now()),
  db.prepare('DELETE FROM shared_aliases WHERE request_key=?').bind(requestKey(input))
 ]);
 return true;
}
