import revision from '../data/cache-version.json';
import type {Answer} from '../lib/rail';
import {type Database,type StoredInput,requestKey,checkedCache} from './storage';

// Sharing is explicit on each request. Old clients that omit it remain private.
// Shared entries never contain a visitor identifier, chat ID or prior conversation.
export function sharingStatus(input:StoredInput):'enabled'|'off'|'conversation'|'sensitive'|'unsupported'{
 if(!input.shareAnswer)return 'off';
 if(input.history.length)return 'conversation';
 if(input.company!=='hokkaido'||!input.aiEnabled)return 'unsupported';
 const q=input.question.normalize('NFKC');
 if(/氏名|姓名|名前|住所|電話番号|メールアドレス|生年月日|社員番号|社員ID|顧客番号|パスワード|暗証|口座|カード番号|社外秘|秘密|診断|病名|手帳番号/i.test(q)||/[\w.+-]+@[\w.-]+\.[a-z]{2,}/i.test(q)||/(?:\d[ -]?){10,}/.test(q))return 'sensitive';
 return 'enabled';
}
export async function sharedAnswer(db:Database,input:StoredInput){
 if(sharingStatus(input)!=='enabled')return null;
 const row=await db.prepare('SELECT answer_json,created FROM shared_answers WHERE request_key=? AND revision=?').bind(requestKey(input),revision.sha256).first<{answer_json:string;created:number}>();
 if(!row)return null;
 const answer=checkedCache(row.answer_json);
 if(!answer||answer.company!==input.company||answer.journeyDate!==input.journeyDate)return null;
 return{answer:{...answer,id:crypto.randomUUID(),question:input.question},generatedAt:row.created};
}
export async function saveSharedAnswer(db:Database,input:StoredInput,answer:Answer){
 if(sharingStatus(input)!=='enabled'||!checkedCache(JSON.stringify(answer)))return false;
 // Do not copy A's history, request/answer identifiers or private comparison into B's response.
 const clean={...answer,id:'',question:''};delete clean.delivery;
 await db.prepare('INSERT INTO shared_answers(request_key,revision,answer_json,created) VALUES(?,?,?,?) ON CONFLICT(request_key) DO UPDATE SET answer_json=excluded.answer_json,created=excluded.created,revision=excluded.revision').bind(requestKey(input),revision.sha256,JSON.stringify(clean),answer.delivery?.generatedAt??Date.now()).run();
 return true;
}
