import {embeddingModel} from '../lib/semantic-search';
import {type Database,hash,readEmbedding,writeEmbedding} from './storage';
type EmbedEnv={DB?:Database;AI?:{run(model:string,input:Record<string,unknown>):Promise<unknown>}};
export type Embed=(question:string)=>Promise<number[]>;
export function embeddingSession(env:EmbedEnv):Embed{
 const pending=new Map<string,Promise<number[]>>();
 return question=>{let promise=pending.get(question);if(!promise){promise=(async()=>{
  const key=hash([embeddingModel,question]);if(env.DB)try{const saved=await readEmbedding(env.DB,key);if(saved)return saved;}catch{}
  const result=await env.AI!.run(embeddingModel,{text:[question]}) as {data?:unknown[]};const vector=result?.data?.[0];
  if(!Array.isArray(vector)||vector.length!==1024||!vector.every(x=>typeof x==='number'&&Number.isFinite(x)))throw new Error('Invalid search embedding');
  if(env.DB)try{await writeEmbedding(env.DB,key,vector);}catch{}
  return vector as number[];
 })();pending.set(question,promise);}return promise;};
}
