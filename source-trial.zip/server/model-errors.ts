export type Stage='embedding'|'selection'|'generation'|'validation';
export type Diagnostic={stage:Stage;reason:'quota'|'capacity'|'timeout'|'access'|'request'|'format'|'citation'|'incomplete'|'provider';providerCode?:number;httpStatus?:number;recovered:boolean};
export class ModelFailure extends Error{
 constructor(public reason:Diagnostic['reason']){super(reason);}
}
export function diagnostic(error:unknown,stage:Stage):Diagnostic{
 const e=error as {message?:string;code?:number;status?:number;cause?:{code?:number;status?:number};errors?:{code?:number}[]};
 const message=typeof e?.message==='string'?e.message:'';
 const code=Number(e?.code??e?.errors?.[0]?.code??e?.cause?.code??Number(message.match(/\b(3036|3040|3007|3008|5035|5007|5018|3023|3006|4006)\b/i)?.[1]));
 const status=Number(e?.status??e?.cause?.status??Number(message.match(/(?:HTTP|status)\s*[:=]?\s*([45]\d{2})\b/i)?.[1]));
 const reason=error instanceof ModelFailure?error.reason:code===3036||(code===4006&&/daily free allocation|daily.*neuron/i.test(message))?'quota':code===3040?'capacity':code===3007?'timeout':[5035,5018,3023].includes(code)?'access':[5007,3006].includes(code)||message==='Prompt too long'?'request':error instanceof SyntaxError||message==='Invalid answer'?'format':message==='Incomplete answer'?'incomplete':stage==='validation'?'citation':'provider';
 return {stage,reason,...(Number.isInteger(code)&&code>=1000&&code<10000?{providerCode:code}:{}),...(Number.isInteger(status)&&status!>=400&&status!<=599?{httpStatus:status}:{}),recovered:false};
}
export function retryable(d:Diagnostic){if(d.providerCode===3008)return false;return ['format','citation','incomplete','capacity','timeout'].includes(d.reason)||(d.reason==='provider'&&d.httpStatus!==429&&d.httpStatus!==403&&d.httpStatus!==400);}
// Extract exactly one complete JSON object. Never invent fields, quotes or IDs.
export function parseModelJson(value:unknown):unknown{
 if(value&&typeof value==='object')return value;
 if(typeof value!=='string'||!value||value.length>16000)throw new ModelFailure('format');
 let text=value.replace(/^\s*<think>[\s\S]*?<\/think>\s*/,'').trim().replace(/^```(?:json)?\s*/,'').replace(/\s*```$/,'');
 try{return JSON.parse(text);}catch{}
 const start=text.indexOf('{');if(start<0)throw new ModelFailure('format');let depth=0,quoted=false,escaped=false;
 for(let i=start;i<text.length;i++){const c=text[i];if(quoted){if(escaped)escaped=false;else if(c==='\\')escaped=true;else if(c==='"')quoted=false;}else if(c==='"')quoted=true;else if(c==='{')depth++;else if(c==='}'&&--depth===0){const after=text.slice(i+1);if(/[{}]/.test(after))throw new ModelFailure('format');try{return JSON.parse(text.slice(start,i+1));}catch{throw new ModelFailure('format');}}}
 throw new ModelFailure('format');
}
export function failureNotice(d:Diagnostic){
 if(d.reason==='quota')return '本日の無料AI利用枠の上限に達しました。関連する公式資料を表示します。';
 if(d.reason==='access')return '現在、AIの実行サービスを利用できません。関連する公式資料を表示します。';
 if(d.reason==='citation')return '回答と出典の対応を再確認しましたが、確定できませんでした。関連する原文を表示します。';
 if(d.reason==='format'||d.reason==='incomplete')return '回答を再確認しましたが、説明を確定できませんでした。関連する原文を表示します。';
 return 'AIの応答を完了できませんでした。確認に使える公式資料を表示します。時間をおいてお試しください。';
}
