import {sha256} from '@noble/hashes/sha2.js';
import {bytesToHex} from '@noble/hashes/utils.js';
import corpus from '../data/corpus.json';
import revision from '../data/cache-version.json';
import type {Answer,Company,Source} from '../lib/rail';
import {validateAnswer} from '../lib/answer-validation';
import {evidenceUnits} from '../lib/evidence';

export interface Statement {
 bind(...values:unknown[]):Statement;
 first<T=Record<string,unknown>>():Promise<T|null>;
 all<T=Record<string,unknown>>():Promise<{results:T[]}>;
 run():Promise<unknown>;
}
export interface Database {prepare(sql:string):Statement;batch(statements:Statement[]):Promise<unknown>}
export type StoredInput={question:string;company:Company;journeyDate:string;history:{role:string;content:string}[];aiEnabled:boolean;shareAnswer?:boolean;semanticReuse?:boolean};
export type Comparison={question:string;differences:string[];sameText:boolean};
export type Delivery={cacheHit:boolean;generatedAt:number;historySaved:boolean;comparison?:Comparison};
const sources=new Map((corpus.chunks as Source[]).map(s=>[s.id,s]));
export const hash=(value:unknown)=>bytesToHex(sha256(new TextEncoder().encode(JSON.stringify(value))));
// Preserve wording, numbers, whitespace and negation. Similarity never authorizes reuse.
export const requestKey=(input:StoredInput)=>hash([revision.sha256,input.question,input.company,input.journeyDate,input.history,input.aiEnabled]);
const cookieName='__Host-ryoki-history';
export function session(request:Request,headers:Headers){
 const secure=new URL(request.url).protocol==='https:';
 const name=secure?cookieName:'ryoki-history-local';
 let token=request.headers.get('Cookie')?.split(';').map(s=>s.trim()).find(s=>s.startsWith(name+'='))?.slice(name.length+1);
 if(!token||! /^(?:[a-f0-9]{64})$/.test(token)){token=bytesToHex(crypto.getRandomValues(new Uint8Array(32)));}
 headers.append('Set-Cookie',`${name}=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=31536000${secure?'; Secure':''}`);
 return hash(token);
}
export const validId=(v:unknown):v is string=>typeof v==='string'&&/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(v);
export async function listChats(db:Database,owner:string,offset=0){
 const {results}=await db.prepare('SELECT id,title,updated FROM chats WHERE owner=? ORDER BY updated DESC,id DESC LIMIT 51 OFFSET ?').bind(owner,offset).all<{id:string;title:string;updated:number}>();
 return {chats:results.slice(0,50),hasMore:results.length>50};
}
export async function loadChat(db:Database,owner:string,id:string,before=Number.MAX_SAFE_INTEGER){
 const chat=await db.prepare('SELECT id,title,updated FROM chats WHERE owner=? AND id=?').bind(owner,id).first();
 if(!chat)return null;
 const {results}=await db.prepare('SELECT rowid AS cursor,answer_json FROM turns WHERE owner=? AND chat_id=? AND rowid<? ORDER BY rowid DESC LIMIT 31').bind(owner,id,before).all<{cursor:number;answer_json:string}>();
 const rows=results.slice(0,30);
 return {...chat,answers:rows.reverse().map(r=>JSON.parse(r.answer_json) as Answer),olderCursor:results.length>30?rows[0].cursor:undefined};
}
export async function deleteChat(db:Database,owner:string,id?:string){
 await db.batch(id?[
  db.prepare('DELETE FROM turns WHERE owner=? AND chat_id=?').bind(owner,id),
  db.prepare('DELETE FROM chats WHERE owner=? AND id=?').bind(owner,id)
 ]:[db.prepare('DELETE FROM turns WHERE owner=?').bind(owner),db.prepare('DELETE FROM chats WHERE owner=?').bind(owner)]);
}
export async function savedRequest(db:Database,owner:string,id:string){
 const row=await db.prepare('SELECT answer_json,request_key FROM turns WHERE owner=? AND id=?').bind(owner,id).first<{answer_json:string;request_key:string}>();
 return row?{answer:JSON.parse(row.answer_json) as Answer,key:row.request_key}:null;
}
export function checkedCache(value:string):Answer|null{
 try{
  const a=JSON.parse(value) as Answer;
  if(a.mode!=='ai'||a.confidence==='insufficient'||!a.sections.length||!a.sources.length)return null;
  const actual=a.sources.map(s=>sources.get(s.id));
  if(actual.some(s=>!s)||actual.some((s,i)=>JSON.stringify(s)!==JSON.stringify(a.sources[i])))return null;
  validateAnswer(structuredClone(a),actual as Source[]);
  for(const section of a.sections){
   if(!section.evidence?.length||!section.source_ids.length)return null;
   for(const quote of section.evidence){const s=sources.get(quote.source_id);if(!s||!section.source_ids.includes(s.id)||!evidenceUnits(s,'S').some(u=>u.quote===quote.quote))return null;}
  }
  return a;
 }catch{return null;}
}
export async function cachedAnswer(db:Database,owner:string,input:StoredInput){
 const row=await db.prepare("SELECT answer_json,created FROM turns WHERE owner=? AND request_key=? AND revision=? AND mode='ai' AND created>? ORDER BY created DESC LIMIT 1").bind(owner,requestKey(input),revision.sha256,Date.now()-7*86400000).first<{answer_json:string;created:number}>();
 if(!row)return null;
 const answer=checkedCache(row.answer_json);return answer?{answer:{...answer,id:crypto.randomUUID(),question:input.question},generatedAt:answer.delivery?.generatedAt??row.created}:null;
}
export async function saveAnswer(db:Database,owner:string,chatId:string,requestId:string,input:StoredInput,answer:Answer){
 const now=Date.now();
 const saved={...answer,delivery:{...answer.delivery,cacheHit:answer.delivery?.cacheHit??false,generatedAt:answer.delivery?.generatedAt??now,historySaved:true}};
 await db.batch([
  db.prepare('INSERT INTO chats(owner,id,title,updated) VALUES(?,?,?,?) ON CONFLICT(owner,id) DO UPDATE SET updated=excluded.updated').bind(owner,chatId,input.question.slice(0,32),now),
  db.prepare('INSERT INTO turns(owner,id,chat_id,question,company,journey_date,context_key,request_key,revision,mode,answer_json,created) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(owner,id) DO NOTHING').bind(owner,requestId,chatId,input.question,input.company,input.journeyDate,hash(input.history),requestKey(input),revision.sha256,answer.mode,JSON.stringify(saved),now)
 ]);
 return saved;
}
function grams(text:string){const s=text.normalize('NFKC').replace(/[\s。、？！!?]/g,'').toLowerCase();return new Set(Array.from({length:Math.max(0,s.length-1)},(_,i)=>s.slice(i,i+2)));}
function similarity(a:string,y:Set<string>){const x=grams(a);let n=0;for(const g of x)if(y.has(g))n++;return 2*n/Math.max(1,x.size+y.size);}
const topicPatterns=[/誤乗|乗り越|乗越|乗り過ご|降り過ご|寝過ご|無賃送還/,/払[い]?戻|払いもど|キャンセル|取消/,/猫|犬|ペット|動物|手回り品|容器/,/子供|子ども|小児|幼児|乳児|赤ちゃん/,/途中下車|途中で降|改札.*外/,/有効期間|有効日|何日|使用期限/,/紛失|なくし|失く|落とし/,/運休|運行不能|遅延|列車.*遅れ/,/定期券|定期乗車券|通勤|通学/];
const topics=(q:string)=>topicPatterns.flatMap((pattern,i)=>pattern.test(q)?[i]:[]);
const numericExpressions=(q:string)=>[...new Set(q.normalize('NFKC').match(/\d+(?:[,\.]\d+)*(?:\s*(?:kg|cm|km|キログラム|キロメートル|キロ|歳|才|人|名|円|日|年|月|回|枚|個))?/gi)??[])];
function wordingDiff(before:string,after:string){
 let p=0,s=0;while(p<before.length&&p<after.length&&before[p]===after[p])p++;
 while(s<before.length-p&&s<after.length-p&&before[before.length-1-s]===after[after.length-1-s])s++;
 const a=before.slice(p,before.length-s),b=after.slice(p,after.length-s);
 return `質問文の変更:「${a.slice(0,120)||'（なし）'}」→「${b.slice(0,120)||'（なし）'}」`;
}
export async function comparePrevious(db:Database,owner:string,input:StoredInput):Promise<Comparison|undefined>{
 const {results}=await db.prepare('SELECT question,company,journey_date,context_key FROM turns WHERE owner=? ORDER BY created DESC LIMIT 200').bind(owner).all<{question:string;company:string;journey_date:string;context_key:string}>();
 const target=grams(input.question),theme=topics(input.question),ranked=results.map(r=>({r,score:Math.min(1,similarity(r.question,target)+(topics(r.question).some(t=>theme.includes(t))?0.3:0))})).sort((a,b)=>b.score-a.score);
 const best=ranked[0];if(!best||best.score<0.55)return;
 const r=best.r,differences:string[]=[];
 const oldNumbers=numericExpressions(r.question),newNumbers=numericExpressions(input.question);
 if(JSON.stringify(oldNumbers)!==JSON.stringify(newNumbers))differences.push(`数値・単位の表現: ${oldNumbers.join('、')||'記載なし'} → ${newNumbers.join('、')||'記載なし'}`);
 if(r.question!==input.question)differences.push(wordingDiff(r.question,input.question));
 if(r.company!==input.company)differences.push('対象会社が異なります。');
 if(r.journey_date!==input.journeyDate)differences.push(`利用日: ${r.journey_date} → ${input.journeyDate}`);
 if(r.context_key!==hash(input.history))differences.push('会話の前提が異なります。');
 if(!differences.length)differences.push('同一の質問ですが、資料・処理の版や回答の状態を再確認します。');
 return{question:r.question,differences,sameText:r.question===input.question};
}
export async function readEmbedding(db:Database,key:string):Promise<number[]|null>{
 const row=await db.prepare('SELECT value_json FROM embeddings WHERE key=? AND created>?').bind(key,Date.now()-7*86400000).first<{value_json:string}>();
 if(!row)return null;
 try{const v=JSON.parse(row.value_json);return Array.isArray(v)&&v.length===1024&&v.every(n=>typeof n==='number'&&Number.isFinite(n))?v:null;}catch{return null;}
}
export async function writeEmbedding(db:Database,key:string,embedding:unknown){
 if(!Array.isArray(embedding)||embedding.length!==1024||!embedding.every(n=>typeof n==='number'&&Number.isFinite(n)))return;
 await db.prepare('INSERT INTO embeddings(key,value_json,created) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json,created=excluded.created').bind(key,JSON.stringify(embedding),Date.now()).run();
}
export async function readSelection(db:Database,key:string){
 const row=await db.prepare('SELECT value_json FROM selections WHERE key=? AND created>?').bind(key,Date.now()-7*86400000).first<{value_json:string}>();
 if(!row)return null;try{const ids=JSON.parse(row.value_json);return Array.isArray(ids)&&ids.length>0&&ids.length<=3&&ids.every(id=>typeof id==='string'&&/^S(?:[1-9]|10)$/.test(id))?ids as string[]:null;}catch{return null;}
}
export async function writeSelection(db:Database,key:string,ids:string[]){
 await db.prepare('INSERT INTO selections(key,value_json,created) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json,created=excluded.created').bind(key,JSON.stringify(ids),Date.now()).run();
}
export const selectionKey=(payload:unknown)=>hash([revision.sha256,payload]);
