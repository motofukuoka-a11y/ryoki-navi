import {catalog,type Answer,type Company} from '../lib/rail';
import {prepareAnswer} from '../lib/guest-answer';
import {finishAnswer} from '../lib/answer-validation';
import type {AnswerPlan} from '../lib/ai-contract';

export const model='@cf/google/gemma-4-26b-a4b-it';
export interface Env{
 AI?:{run(model:string,input:Record<string,unknown>):Promise<unknown>};
 FREE_PLAN_CONFIRMED?:string;
 ASSETS?:{fetch(request:Request):Promise<Response>};
}
type Input={question:string;company:Company;journeyDate:string;history:{role:string;content:string}[];aiEnabled:boolean};
function ready(env:Env){return env.FREE_PLAN_CONFIRMED==='1'&&!!env.AI;}

async function readInput(request:Request){
 const reader=request.body?.getReader();if(!reader)return '';
 const chunks:Uint8Array[]=[];let size=0;
 try{for(;;){const {value,done}=await reader.read();if(done)break;size+=value.length;if(size>32000){await reader.cancel();return null;}chunks.push(value);}}
 finally{reader.releaseLock();}
 const bytes=new Uint8Array(size);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}
 return new TextDecoder().decode(bytes);
}

function parseInput(value:unknown):Input{
 if(!value||typeof value!=='object')throw new Error('Invalid input');
 const v=value as Record<string,unknown>;
 if(typeof v.question!=='string'||!v.question.trim()||v.question.length>2500||!['hokkaido','east','both'].includes(String(v.company))||typeof v.journeyDate!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(v.journeyDate)||typeof v.aiEnabled!=='boolean')throw new Error('Invalid input');
 const history=Array.isArray(v.history)?v.history.slice(-4).flatMap(item=>item&&typeof item==='object'&&['user','assistant'].includes(item.role)&&typeof item.content==='string'?[{role:item.role,content:item.content.slice(0,350)}]:[]):[];
 return {question:v.question.trim(),company:v.company as Company,journeyDate:v.journeyDate,history,aiEnabled:v.aiEnabled};
}

async function complete(env:Env,plan:AnswerPlan,draft?:unknown){
 const payload=draft===undefined?plan.payload:{...plan.payload,reviewedExamples:[],draft};
 // Show an answer instance rather than the JSON Schema, which can be copied as output.
 const template={summary:'質問に対する結論',sections:[{heading:'根拠',body:'資料と質問条件を照合した説明',source_ids:['S1']}],confidence:'conditional',followup:[],assumptions:[]};
 const system=plan.system+' 出力は次の形の回答オブジェクト。各値を質問に応じた実際の回答に置き換える。typeやpropertiesを出力してはならない。'+JSON.stringify(template)+(draft===undefined?'':' 校閲者として草案をsourcesと一文ずつ照合し、数値の対象・合計範囲・否定・例外・出典IDを検証する。誤読と無関係な節を修正した最終回答オブジェクトだけを返す。');
 const body={messages:[{role:'system',content:system},{role:'user',content:JSON.stringify(payload)}],stream:false,store:false,temperature:0,max_tokens:1500,max_completion_tokens:1500,chat_template_kwargs:{enable_thinking:false},response_format:{type:'json_object'}};
 if(new TextEncoder().encode(JSON.stringify(body)).length>48000)throw new Error('Prompt too long');
 const response=await env.AI!.run(model,body) as {response?:string;usage?:{completion_tokens?:number};choices?:{finish_reason?:string;message?:{content?:string}}[]};
 const choice=response?.choices?.[0];
 if(choice&&choice.finish_reason!=='stop')throw Object.assign(new Error('Incomplete answer'),{details:{finishReason:choice.finish_reason??'missing',completionTokens:response.usage?.completion_tokens,characters:choice.message?.content?.length}});
 const text=choice?.message?.content||response?.response;
 if(typeof text!=='string'||!text||text.length>12000)throw new Error('Invalid answer');
 return JSON.parse(text.replace(/^\s*<think>[\s\S]*?<\/think>\s*/,'').replace(/^```(?:json)?\s*/,'').replace(/\s*```$/,''));
}

export async function answerQuestion(input:Input,env:Env,signal:AbortSignal):Promise<Answer>{
 const {question,company,journeyDate,history,aiEnabled}=input;
 const prepared=prepareAnswer(question,company,journeyDate,history,aiEnabled,ready(env));
 if(prepared.answer)return prepared.answer;
 let phase:'generation'|'validation'='generation';
 try{
  signal.throwIfAborted();
  // Workers Free enforces its own daily allocation. No gateway, credits, retries,
  // paid-plan enrollment, or alternate model is used when an AI call fails.
  const draft=await complete(env,prepared.plan!);
  phase='validation';
  finishAnswer(draft,prepared.sources!,question,company,journeyDate);
  signal.throwIfAborted();
  phase='generation';
  const reviewed=await complete(env,prepared.plan!,draft);
  signal.throwIfAborted();
  phase='validation';
  return finishAnswer(reviewed,prepared.sources!,question,company,journeyDate);
 }catch(error){
  if(signal.aborted)throw error;
  const message=error instanceof Error?error.message:'';
  const failureCode=phase==='validation'?'citation':message==='Incomplete answer'?'incomplete':message==='Invalid answer'||error instanceof SyntaxError?'format':'provider';
  const notice=failureCode==='citation'?'AI回答の出典を確認できなかったため、回答生成を中止しました。関連する原文を表示します。':failureCode==='incomplete'?'AI回答が生成上限内に完成しなかったため、関連する原文を表示します。':failureCode==='format'?'AI回答の形式を確認できなかったため、関連する原文を表示します。':'無料枠の上限または接続障害により、サーバーAIを利用できませんでした。関連する原文を表示します。有料サービスへの切り替えは行いません。';
  // A bounded category helps diagnose failures without returning provider messages or prompts.
  const details=failureCode==='incomplete'?(error as {details?:unknown}).details:undefined;
  return Object.assign({...prepared.fallback!,notice},{failureCode,...(details?{failureDetails:details}:{})});
 }
}

export default {async fetch(request:Request,env:Env):Promise<Response>{
 const url=new URL(request.url),origin=request.headers.get('Origin');
 const allowed=!origin||origin===url.origin||origin==='https://motofukuoka-a11y.github.io'||/^http:\/\/127\.0\.0\.1:(5178|8787)$/.test(origin);
 const headers=new Headers({'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Vary':'Origin'});
 if(origin&&allowed)headers.set('Access-Control-Allow-Origin',origin);
 if(url.pathname.startsWith('/api/')&&!allowed)return Response.json({error:'Access denied'},{status:403,headers});
 if(request.method==='OPTIONS'){
  headers.set('Access-Control-Allow-Methods','GET, POST, OPTIONS');headers.set('Access-Control-Allow-Headers','Content-Type');
  return new Response(null,{status:204,headers});
 }
 if(url.pathname==='/api/bootstrap'&&request.method==='GET')return Response.json({catalog,aiReady:ready(env),model:'Gemma 4',freeOnly:true,quota:'provider-daily-allocation'},{headers});
 if(url.pathname==='/api/answer'&&request.method==='POST'){
  if(!request.headers.get('Content-Type')?.startsWith('application/json'))return Response.json({error:'JSON required'},{status:415,headers});
  if(Number(request.headers.get('Content-Length')||0)>32000)return Response.json({error:'Input too long'},{status:413,headers});
  const text=await readInput(request);
  if(text===null)return Response.json({error:'Input too long'},{status:413,headers});
  let input:Input;try{input=parseInput(JSON.parse(text));}catch{return Response.json({error:'質問・対象会社・利用日を確認してください。'},{status:400,headers});}
  try{return Response.json(await answerQuestion(input,env,request.signal),{headers});}
  catch{return Response.json({error:'処理を中止しました。'},{status:499,headers});}
 }
 if(url.pathname.startsWith('/api/'))return Response.json({error:'Not found'},{status:404,headers});
 return env.ASSETS?env.ASSETS.fetch(request):new Response('旅規ナビ API',{headers});
}};
