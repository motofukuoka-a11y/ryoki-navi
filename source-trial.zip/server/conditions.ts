// These guards reject changes before asking a model. A matching fingerprint alone
// NEVER authorizes reuse: the full questions must also pass the semantic check.
const numberValue=(s:string)=>{
 if(/^[\d.]+$/.test(s))return Number(s);
 const digits:Record<string,number>={'〇':0,'零':0,'一':1,'二':2,'三':3,'四':4,'五':5,'六':6,'七':7,'八':8,'九':9};
 let total=0,current=0;for(const c of s){if(c in digits)current=current*10+digits[c];else if(c==='十'||c==='百'||c==='千'){total+=(current||1)*({十:10,百:100,千:1000}[c]);current=0;}else if(c==='万'){total=(total+current||1)*10000;current=0;}else return NaN;}return total+current;
};
const normalize=(q:string)=>q.normalize('NFKC').replace(/(?<=\d),(?=\d{3}(?:\D|$))/g,'').replace(/([〇零一二三四五六七八九十百千万]+)(?=\s*(?:人|名|歳|才|円|日|年|月|回|枚|個|条|駅|号|種|等|匹|キロ|センチ|メートル))/g,s=>String(numberValue(s))).toLowerCase();
const sorted=(items:string[])=>[...new Set(items)].sort();
const matches=(q:string,patterns:[string,RegExp][])=>patterns.flatMap(([key,p])=>p.test(q)?[key]:[]).sort();
const tickets:[string,RegExp][]=[['commuter',/定期(?:乗車)?券|定期(?:で|を|の(?:有効|区間))/],['credit_combined',/クレジットカード一体型|一体型kitaca/],['named',/記名(?:式|kitaca)|記名キタカ/],['unnamed',/無記名(?:式|kitaca)|無記名キタカ/],['commuting',/通勤定期/],['school',/通学定期/],['ordinary',/普通(?:の)?(?:乗車券|切符|きっぷ)/],['coupon',/回数(?:乗車)?券/],['ic',/icカード|ic乗車|kitaca|suica/],['limited_express_ticket',/特急券/],['express_ticket',/(?<!特)急行券/],['reserved_ticket',/指定席券/],['round_trip',/往復(?:乗車)?券/]];
const usage:[string,RegExp][]=[['unused',/未使用|使用前|使(?:用)?う前|(?:使って|使用して|利用して)(?:いない|いません)|使わなかった|使用しなかった|まだ(?:使|使用|利用)(?:って|して)?い?ない|一度も(?:使|使用|利用).{0,8}(?:ない|ません)/],['used',/使用済|使用後|使った|使用した|利用した|利用済|既に使|すでに使|使用開始後|一部(?:使|使用)|途中まで(?:使|使用)/],['before_departure',/発車前|出発前|乗車前/],['after_departure',/発車後|出発後|乗車後/],['intentional',/故意|わざと|意図的|承知で/],['accidental',/誤って|間違って|間違えて|うっかり|誤つて/]];
const seats:[string,RegExp][]=[['reserved',/指定席/],['unreserved',/自由席/],['standing',/立席/],['green',/グリーン|特別車両/],['local',/普通列車|各駅停車/],['rapid',/快速/],['limited_express',/特急/],['express',/(?<!特)急行/],['shinkansen',/新幹線/]];
const tasks:[string,RegExp][]=[['issue',/発行|発売|購入|買え|買う|買いたい|作れ|作る|郵送/],['card_use',/使え|利用エリア|どこまで|利用可能/],['refund',/払[い]?戻|払いもど|返金|キャンセル|取消/],['overrun',/誤乗|無賃送還|乗り越|乗越|乗り過ご|降り過ご|寝過ご/],['pet',/猫|犬|ペット|小動物|動物/],['children',/小児|子ども|子供|こども|幼児|乳児|歳|才/],['stopover',/途中下車|途中で降|途中駅.*改札/],['validity',/有効期間|有効日|何日|使用期限/],['change',/乗車変更|区間変更|変更した/],['loss',/紛失|なくした|失くした/]];
const cardTypes:[string,RegExp][]=[['card_kitaca',/kitaca|キタカ/],['card_suica',/suica|スイカ/],['card_sapica',/sapica|サピカ/],['card_pasmo',/pasmo/],['card_icoca',/icoca/],['card_nimoca',/nimoca/],['card_sugoca',/sugoca/],['card_toica',/toica/],['card_manaca',/manaca/],['card_hayakaken',/はやかけん/]];
export type Conditions={tickets:string[];usage:string[];seats:string[];animals:string[];focus:string[];temporal:string[];numbers:string[];negations:string[];articles:string[];route:string[];topic:string};
export function conditionProfile(question:string):Conditions{
 const q=normalize(question),numbers:string[]=[];
 for(const m of q.matchAll(/\d+(?:\.\d+)?\s*(?:キログラム|キロメートル|センチメートル|メートル|キロ|センチ|kg|km|cm|g|m|歳|才|人|名|円|日|年|月|回|枚|個|条|駅|号|種|等|匹)?/g)){
  const raw=m[0],n=Number(raw.match(/^[\d.]+/)![0]),unit=raw.replace(/^[\d.]+\s*/,''),before=q.slice(Math.max(0,m.index!-36),m.index),after=q.slice(m.index!+raw.length,m.index!+raw.length+10);
  let role='',scale=1,canonicalUnit=unit;
  if(/^(人|名)$/.test(unit)){
   canonicalUnit='persons';const context=before.split(/[。、,;！？?]/).at(-1)!;
   const labels=[...context.matchAll(/大人|成人|おとな|小児|子供|子ども|こども|幼児|乳児|赤ちゃん|\d+\s*[歳才](?:児|の子|の幼児)?/g)];
   const label=labels.at(-1)?.[0]??'',age=context.slice(-18).match(/(\d+)\s*[歳才]/);role=/大人|成人|おとな/.test(label)?'adult':age?'age_'+age[1]:/乳児/.test(label)?'infant':/赤ちゃん/.test(label)?'baby_unspecified':/幼児/.test(label)?'young_child':/小児|子/.test(label)?'child':'unspecified';
  }else if(/^(歳|才)$/.test(unit))canonicalUnit='age';
  else if(/^(kg|g|キロ|キログラム)$/.test(unit)){
   canonicalUnit='g';scale=unit==='g'?1:1000;
   if(/合計|合わせ|あわせ|総重量|含め|込み|収納(?:した|後)/.test(before))role='total';
   else {const labels=[...before.matchAll(/猫|犬|ペット|動物|容器|ケース|キャリー|ケージ/g)];const label=labels.at(-1)?.[0]??'';role=/容器|ケース|キャリー|ケージ/.test(label)?'container':/猫|犬|ペット|動物/.test(label)?'animal':'unspecified';}
  }else if(/^(cm|m|センチ|センチメートル|メートル)$/.test(unit)){
   canonicalUnit='cm';scale=/^(m|メートル)$/.test(unit)?100:1;
   const label=[...before.matchAll(/合計|3辺の和|三辺の和|各辺|縦|たて|高さ|横|よこ|幅|奥行/g)].at(-1)?.[0]??'';
   role=/合計|辺の和/.test(label)?'sum':/各辺/.test(label)?'per_side':/縦|たて|高さ/.test(label)?'height':/横|よこ|幅/.test(label)?'width':/奥行/.test(label)?'depth':'unspecified';
  }
  const bound=after.match(/^\s*(以内|以下|以上|未満|まで|超過|超|より多|より少)/)?.[1]??'';
  numbers.push([canonicalUnit||'untyped',role,Math.round(n*scale*1e6)/1e6,/以内|まで/.test(bound)?'以下':bound].join(':'));
 }
 const negations=[...q.matchAll(/(?:未使用|定期(?:乗車)?券|普通乗車券|指定席|自由席|使用済み?|使用した|使った)(?:では|で|じゃ|を)?(?:ない|なく|ありません)|(?:除く|以外|のみ|だけ|限定|に限る|に限って)/g)].map(m=>m[0].replace(/だけ|のみ|限定|に限る|に限って/g,'only'));
 const articles=[...q.matchAll(/第\s*(\d+)\s*条(?:の(\d+))?/g)].map(m=>m[1]+(m[2]?'.'+m[2]:''));
 const stationNames=[...q.matchAll(/([\p{Script=Han}\p{Script=Katakana}a-z]{2,12})駅/gmu)].map(m=>m[1]);
 const directions:string[]=[],endpoints=new Set<string>();
 for(const m of q.matchAll(/([\p{Script=Han}\p{Script=Katakana}a-z]{2,10})(?:駅)?\s*(?:から|発|→)\s*[、,]?\s*([\p{Script=Han}\p{Script=Katakana}a-z]{2,10})(?:駅)?/gmu)){
  const from=m[1].replace(/駅$/,''),to=m[2].replace(/駅$/,'');directions.push('direction:'+from+':'+to);endpoints.add(from);endpoints.add(to);
 }
 const route=[...stationNames.filter(s=>!endpoints.has(s)),...directions,...[...q.matchAll(/([\p{Script=Han}\p{Script=Katakana}a-z]{2,10})(?:駅)?経由/gmu)].map(m=>'via:'+m[1].replace(/駅$/,''))];
 const themes=matches(q,tasks);
 const focus=matches(q,[['cost',/いくら|何円|手数料|料金を教|料金は|料金が/],['count',/何人|何名|人数/],['limit',/上限|何キロ|何kg|何cm|何センチ/],['issuance',/発行|発売|購入|郵送/],['card_area',/利用エリア|どこまで|利用可能/],['procedure',/手続き(?:は|を|の方法)|手続方法|手順|方法|どうすれば/]]);
 return{tickets:sorted([...matches(q,tickets),...matches(q,cardTypes)]),usage:matches(q,usage),seats:matches(q,seats),animals:matches(q,[['cat',/猫/],['dog',/犬/]]),focus,temporal:matches(q,[['today',/今日|本日/],['tomorrow',/明日/],['yesterday',/昨日/],['same_day',/当日/],['next_day',/翌日/],['previous_day',/前日/]]),numbers:numbers.sort(),negations:sorted(negations),articles:sorted(articles),route:sorted(route),topic:themes[0]??'general'};
}
export function conditionDifferences(a:Conditions,b:Conditions){
 return (['tickets','usage','seats','animals','focus','temporal','numbers','negations','articles','route'] as const).filter(key=>JSON.stringify(a[key])!==JSON.stringify(b[key]));
}
export const compatibleConditions=(a:Conditions,b:Conditions)=>conditionDifferences(a,b).length===0;
