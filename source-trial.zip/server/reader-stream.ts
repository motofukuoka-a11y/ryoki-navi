// Complete cited sections can be shown while the same reader finishes its JSON.
// Reasoning deltas and incomplete/unverified sections never leave the server.
function endValue(text:string,start:number){
 let quote=false,escape=false,depth=0;
 for(let i=start;i<text.length;i++){const c=text[i];if(quote){if(escape)escape=false;else if(c==='\\')escape=true;else if(c==='"'){quote=false;if(depth===0)return i+1;}continue;}if(c==='"')quote=true;else if(c==='['||c==='{')depth++;else if(c===']'||c==='}'){depth--;if(depth===0)return i+1;}else if(depth===0&&(c===','||/\s/.test(c)))return i;}
 return -1;
}
export function partialAnswer(text:string):unknown|null{
 try{let pos=text.indexOf('{')+1;if(pos!==1)return null;const fields:Record<string,unknown>={},seen=new Set<string>();let conclusion:unknown=null;
  while(pos<text.length){while(/[\s,]/.test(text[pos]??'')&&pos<text.length)pos++;if(text[pos]!== '"')return conclusion;const end=endValue(text,pos);if(end<0)return conclusion;const key=JSON.parse(text.slice(pos,end));if(seen.has(key))return null;seen.add(key);pos=end;while(/\s/.test(text[pos]??'')&&pos<text.length)pos++;if(text[pos++]!==':')return null;while(/\s/.test(text[pos]??'')&&pos<text.length)pos++;
   if(key==='sections'){if(text[pos++]!=='[')return null;const sections:unknown[]=[];while(pos<text.length&&sections.length<4){while(/[\s,]/.test(text[pos]??'')&&pos<text.length)pos++;if(text[pos]!== '{')break;const stop=endValue(text,pos);if(stop<0)break;sections.push(JSON.parse(text.slice(pos,stop)));pos=stop;}return typeof fields.summary==='string'&&sections.length?{summary:fields.summary,sections,confidence:'conditional',followup:[],assumptions:[]}:conclusion;}
   const stop=endValue(text,pos);if(stop<0)return conclusion;fields[key]=JSON.parse(text.slice(pos,stop));pos=stop;
   if(key==='summary_evidence_ids'&&typeof fields.summary==='string'&&Array.isArray(fields[key])&&fields[key].length>0&&fields[key].length<=3&&fields[key].every(x=>typeof x==='string'))conclusion={summary:fields.summary,sections:[{heading:'結論',body:fields.summary,evidence_ids:fields[key]}],confidence:'conditional',followup:[],assumptions:[]};
  }return conclusion;
 }catch{return null;}
}
export async function readModelJson(stream:ReadableStream<Uint8Array>,signal:AbortSignal,onPartial:(value:unknown)=>void){
 const reader=stream.getReader(),decoder=new TextDecoder();let buffer='',content='',finish:string|undefined,lastSections=0;
 function packet(block:string){const data=block.split('\n').filter(l=>l.startsWith('data:')).map(l=>l.slice(5).trimStart()).join('\n');if(!data||data==='[DONE]')return;const event=JSON.parse(data);if(event.error)throw new Error('Provider stream failed');const choice=event.choices?.[0];if(choice?.finish_reason)finish=choice.finish_reason;const delta=choice?.delta?.content??event.response;if(typeof delta!=='string')return;content+=delta;if(content.length>16000)throw new Error('Invalid answer');const partial=partialAnswer(content) as {sections?:unknown[]}|null;if(partial?.sections&&partial.sections.length>lastSections){onPartial(partial);lastSections=partial.sections.length;}}
 try{for(;;){signal.throwIfAborted();const {done,value}=await reader.read();signal.throwIfAborted();buffer+=decoder.decode(value,{stream:!done}).replace(/\r\n/g,'\n');if(buffer.length>2000000)throw new Error('Invalid answer');let at;while((at=buffer.indexOf('\n\n'))>=0){packet(buffer.slice(0,at));buffer=buffer.slice(at+2);}if(done)break;}if(buffer.trim())packet(buffer);if(finish&&finish!=='stop')throw new Error('Incomplete answer');if(!content||!finish)throw new Error('Incomplete answer');return JSON.parse(content.replace(/^\s*<think>[\s\S]*?<\/think>\s*/,'').replace(/^```(?:json)?\s*/,'').replace(/\s*```$/,''));}
 finally{try{await reader.cancel();}catch{}reader.releaseLock();}
}
