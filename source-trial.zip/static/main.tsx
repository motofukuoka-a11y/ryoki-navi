import {createRoot} from 'react-dom/client';
import RailChat from '../components/rail-chat';
import '../app/globals.css';
createRoot(document.getElementById('root')!).render(<RailChat/>);
