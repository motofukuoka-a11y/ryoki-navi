CREATE TABLE IF NOT EXISTS chats (
 owner TEXT NOT NULL, id TEXT NOT NULL, title TEXT NOT NULL, updated INTEGER NOT NULL,
 PRIMARY KEY(owner,id)
);
CREATE INDEX IF NOT EXISTS chats_owner_updated ON chats(owner,updated DESC);
CREATE TABLE IF NOT EXISTS turns (
 owner TEXT NOT NULL, id TEXT NOT NULL, chat_id TEXT NOT NULL,
 question TEXT NOT NULL, company TEXT NOT NULL, journey_date TEXT NOT NULL,
 context_key TEXT NOT NULL, request_key TEXT NOT NULL, revision TEXT NOT NULL,
 mode TEXT NOT NULL, answer_json TEXT NOT NULL, created INTEGER NOT NULL,
 PRIMARY KEY(owner,id)
);
CREATE INDEX IF NOT EXISTS turns_chat ON turns(owner,chat_id,created DESC);
CREATE INDEX IF NOT EXISTS turns_reuse ON turns(owner,request_key,revision,mode,created DESC);
CREATE INDEX IF NOT EXISTS turns_recent ON turns(owner,created DESC);
CREATE TABLE IF NOT EXISTS embeddings(key TEXT PRIMARY KEY,value_json TEXT NOT NULL,created INTEGER NOT NULL);
