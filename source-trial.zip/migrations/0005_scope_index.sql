CREATE INDEX IF NOT EXISTS shared_questions_scope ON shared_questions(revision,company,journey_date,created DESC);
