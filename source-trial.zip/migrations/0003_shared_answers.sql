CREATE TABLE IF NOT EXISTS shared_answers (
 request_key TEXT PRIMARY KEY,
 revision TEXT NOT NULL,
 answer_json TEXT NOT NULL,
 created INTEGER NOT NULL
);
