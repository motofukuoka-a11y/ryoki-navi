CREATE TABLE IF NOT EXISTS shared_questions (
 request_key TEXT PRIMARY KEY, revision TEXT NOT NULL,
 company TEXT NOT NULL, journey_date TEXT NOT NULL, topic TEXT NOT NULL,
 question TEXT NOT NULL, vector_json TEXT NOT NULL, conditions_json TEXT NOT NULL,
 created INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS shared_questions_topic ON shared_questions(revision,company,journey_date,topic,created DESC);
CREATE TABLE IF NOT EXISTS shared_aliases (
 request_key TEXT PRIMARY KEY, canonical_key TEXT NOT NULL, revision TEXT NOT NULL,
 checks_json TEXT NOT NULL, created INTEGER NOT NULL
);
