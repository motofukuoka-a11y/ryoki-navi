// Run only when the public corpus changes. Credentials are read from the process
// environment and are never written into the index, output, or application code.
import {readFile,writeFile,rename} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const account=process.env.CLOUDFLARE_ACCOUNT_ID,token=process.env.CLOUDFLARE_API_TOKEN;
if(!account||!token)throw new Error('Set CLOUDFLARE_ACCOUNT_ID and CLOUDFLARE_API_TOKEN in your local process environment.');
const raw=await readFile('data/corpus.json','utf8'),corpus=JSON.parse(raw);
const sourceHash=s=>createHash('sha256').update(JSON.stringify(s)).digest('hex');
const rows=corpus.chunks.filter(s=>s.evidence==='official_text'||s.evidence==='official_web'),vectors=[];let dimension=1024;
let prior;try{prior=JSON.parse(await readFile('data/semantic-index.json','utf8'));}catch{}
const existing=new Map((prior?.rows||[]).map(r=>[r.id,r])),missing=[];
for(const s of rows){const old=existing.get(s.id);if(old?.sourceSha256===sourceHash(s))vectors.push(old);else missing.push(s);}
for(let i=0;i<missing.length;i+=8){
 const batch=missing.slice(i,i+8);
 const response=await fetch('https://api.cloudflare.com/client/v4/accounts/'+account+'/ai/run/@cf/baai/bge-m3',{method:'POST',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},body:JSON.stringify({text:batch.map(s=>s.title+'\n'+s.text.replace(/\s+/g,' '))}),signal:AbortSignal.timeout(90000)});
 const data=await response.json();
 if(!response.ok||!data.success||!Array.isArray(data.result?.data)||data.result.data.length!==batch.length)throw new Error('Index generation stopped; no retry or paid fallback.');
 for(let j=0;j<batch.length;j++){
  const v=data.result.data[j];dimension||=v.length;
  if(v.length!==dimension||!v.every(Number.isFinite))throw new Error('Invalid embedding');
  const scale=Math.max(...v.map(Math.abs))/127||1,bytes=Int8Array.from(v,x=>Math.round(x/scale));
  vectors.push({id:batch[j].id,sourceSha256:sourceHash(batch[j]),bytes:Buffer.from(bytes.buffer).toString('base64'),norm:Math.hypot(...bytes)});
 }
 console.log('Indexed '+vectors.length+'/'+rows.length+' public passages');
}
const index={model:'@cf/baai/bge-m3',corpusSha256:createHash('sha256').update(raw).digest('hex'),dimension,lexicalOnly:[],rows:vectors};
await writeFile('data/semantic-index.json.tmp',JSON.stringify(index));
await rename('data/semantic-index.json.tmp','data/semantic-index.json');
