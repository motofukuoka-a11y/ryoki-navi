import {build} from 'vite';
import {createHash} from 'node:crypto';
import {resolve,join} from 'node:path';
import {writeFileSync,readdirSync,readFileSync} from 'node:fs';
const arg=process.argv.indexOf('--out-dir'),out=resolve(arg>=0?process.argv[arg+1]:'dist');
const index=JSON.parse(readFileSync(resolve('data/semantic-index.json'),'utf8'));
const officialIds=new Set(JSON.parse(readFileSync(resolve('data/corpus.json'),'utf8')).chunks.filter(s=>s.evidence==='official_text').map(s=>s.id));
if(index.rows.length!==officialIds.size||new Set(index.rows.map(r=>r.id)).size!==officialIds.size||index.rows.some(r=>!officialIds.has(r.id)||Buffer.from(r.bytes,'base64').length!==index.dimension||!Number.isFinite(r.norm)||r.norm<=0))throw new Error('Semantic index is incomplete');
if(index.corpusSha256!==createHash('sha256').update(readFileSync(resolve('data/corpus.json'))).digest('hex'))throw new Error('Semantic index does not match corpus');
await build({configFile:resolve('vite.static.config.ts'),build:{outDir:out,emptyOutDir:true}});
writeFileSync(join(out,'.nojekyll'),'');
const walk=path=>readdirSync(path,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(join(path,e.name)):[join(path,e.name)]);
for(const file of walk(out).filter(f=>/\.(js|html)$/.test(f))){const text=readFileSync(file,'utf8');if(/signin-with-chatgpt|signout-with-chatgpt|auth\.openai\.com|api\.openai\.com|chatgpt\.site|\/api\/chats|\/api\/learning|huggingface\.co|CreateWebWorkerMLCEngine|navigator\.gpu|2\.4GB/.test(text))throw new Error('Unexpected login, local model, or previous-host reference in public build: '+file);}
console.log('Static build verified: no login links, local model download, or account API references.');
