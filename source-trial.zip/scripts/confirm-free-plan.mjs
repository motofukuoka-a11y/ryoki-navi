import {readFileSync,writeFileSync} from 'node:fs';
if(process.argv[2]!=='--confirmed-workers-free')throw new Error('Verify Workers Free in the account dashboard before using --confirmed-workers-free.');
const path='wrangler.jsonc',config=JSON.parse(readFileSync(path,'utf8'));
if(config.ai?.gateway||config.d1_databases||config.r2_buckets)throw new Error('Unexpected paid gateway or storage configuration.');
config.vars.FREE_PLAN_CONFIRMED='1';
writeFileSync(path,JSON.stringify(config,null,2)+'\n');
console.log('Enabled server AI for the verified Workers Free account. No credentials were written.');
