import type {Answer} from './rail';
import type {LightRequest} from './light-answer';
let worker:Worker|null=null;
let pending:{id:string;resolve:(answer:Answer)=>void;reject:(error:Error)=>void;cleanup:()=>void}|null=null;
function reset(){worker?.terminate();worker=null;}
function ensureWorker(){
 if(worker)return worker;
 worker=new Worker(new URL('./light-worker.ts',import.meta.url),{type:'module'});
 worker.onmessage=event=>{
  const active=pending;if(!active||event.data.id!==active.id)return;
  pending=null;active.cleanup();
  if(event.data.error)active.reject(new Error(event.data.error));else active.resolve(event.data.answer);
 };
 worker.onerror=()=>{const active=pending;pending=null;reset();if(active){active.cleanup();active.reject(new Error('検索データを読み込めませんでした。ページを再読み込みしてお試しください。'));}};
 return worker;
}
export function requestLightAnswer(input:LightRequest,signal:AbortSignal):Promise<Answer>{
 signal.throwIfAborted();
 if(pending)return Promise.reject(new Error('前の検索が終わるまでお待ちください。'));
 return new Promise((resolve,reject)=>{
  const id=crypto.randomUUID();
  const abort=()=>{if(pending?.id!==id)return;const active=pending;pending=null;reset();active.cleanup();reject(new DOMException('検索を中止しました。','AbortError'));};
  const timeout=setTimeout(()=>{if(pending?.id!==id)return;const active=pending;pending=null;reset();active.cleanup();reject(new Error('検索データを読み込めませんでした。接続を確認して再試行してください。'));},30000);
  pending={id,resolve,reject,cleanup:()=>{clearTimeout(timeout);signal.removeEventListener('abort',abort);}};
  signal.addEventListener('abort',abort,{once:true});
  try{ensureWorker().postMessage({id,input});}catch{pending.cleanup();pending=null;reset();reject(new Error('このブラウザで検索を開始できませんでした。ページを再読み込みしてお試しください。'));}
 });
}
