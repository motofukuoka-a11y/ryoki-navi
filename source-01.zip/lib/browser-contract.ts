export const browserModel='Qwen3.5-4B-q4f16_1-MLC';
export type BrowserPlan={taskId:string;system:string;payload:Record<string,unknown>;schema:Record<string,unknown>};
