import {referenceAnswer} from './reference';
import {retrieve,searchAnswer,type Company} from './rail';
import {makeBrowserPlan} from './browser-plan';
// Guests use only bundled public JR documents. This module never reads or writes account records.
export function prepareGuest(question:string,company:Company,date:string,history:{role:string;content:string}[],enabled:boolean,ready:boolean){
 const continues=/^(それ|その|では|じゃあ|同じ条件|この場合|いくら|何日|何円|手数料は|有効日数は)/.test(question);
 const query=continues?history.filter(m=>m.role==='user').slice(-1).map(m=>m.content).join(' ')+' '+question:question;
 const search=(notice='')=>({...searchAnswer(query,company,date,notice),question});
 if(!enabled)return{answer:search()};
 if(/kitaca|suica|pasmo|icoca|sugoca|toica|manaca|nimoca|はやかけん|icカード|ic乗車|企画乗車券|フリーきっぷ|おトクなきっぷ|青春18|えきねっと|トクだ値/i.test(question))return{answer:search('専用の規則は未収録です。取扱いを確定できません。')};
 if(company!=='hokkaido'||/JR東日本|ＪＲ東日本/.test(question))return{answer:search('JR東日本の規則は未収録です。取扱いを確定できません。')};
 const reference=referenceAnswer(question,company,date);if(reference)return{answer:reference};
 if(!ready)return{answer:search('会話AIは未起動です。「ブラウザAIを準備」から初回約2.4GBのモデルを取得できます。以下は関連資料の抜粋です。')};
 const scope=[...question.normalize('NFKC').matchAll(/(第\d+条(?:の\d+)?)(?:の範囲|だけ|のみ)/g)].map(m=>m[1]);
 const sources=retrieve(query,company,date,4).filter(s=>s.evidence!=='editorial_note'&&(!scope.length||scope.includes(s.article)));
 if(!sources.length)return{answer:search()};
 const plan=makeBrowserPlan(question,company,date,history,sources,'結論を先に、根拠に基づいて簡潔な日本語で説明する。');
 return{plan,sources:sources.slice(0,plan.sourcesCount),fallback:search('ブラウザAIの回答を完成できなかったため、関連資料の抜粋を表示しています。')};
}
