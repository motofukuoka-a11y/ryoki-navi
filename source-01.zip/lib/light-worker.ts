import {answerLight,type LightRequest} from './light-answer';
const scope=self as unknown as {onmessage:((event:MessageEvent<{id:string;input:LightRequest}>)=>void)|null;postMessage:(value:unknown)=>void};
scope.onmessage=event=>{
 const {id,input}=event.data;
 try{scope.postMessage({id,answer:answerLight(input)});}
 catch{scope.postMessage({id,error:'資料検索を完了できませんでした。条件を短くして再試行してください。'});}
};
