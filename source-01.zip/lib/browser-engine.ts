import type {WebWorkerMLCEngine} from '@mlc-ai/web-llm';
import {browserModel,type BrowserPlan} from './browser-contract';
import BrowserWorker from './browser-worker?worker';
let engine:WebWorkerMLCEngine|null=null,worker:Worker|null=null;
export async function loadBrowserEngine(progress:(text:string)=>void){
 if(engine)return;
 if(!('gpu' in navigator))throw new Error('このブラウザではWebGPUを利用できません。WebGPU対応のChrome・Edge・Safariをお試しください。');
 const mlc=await import('@mlc-ai/web-llm');
 worker=new BrowserWorker();
 try{engine=await mlc.CreateWebWorkerMLCEngine(worker,browserModel,{initProgressCallback:r=>progress('会話モデルを取得・読み込み中（'+Math.round(r.progress*100)+'%）。初回は数分以上かかることがあります。'),logLevel:'WARN'},{context_window_size:8192});}
 catch(e){worker.terminate();worker=null;console.warn('Browser AI initialization failed',e);throw new Error('ブラウザAIを起動できませんでした。ネット接続、端末の空き容量・メモリ、WebGPU対応を確認して再度お試しください。基本案内・資料検索は引き続き利用できます。');}
}
export function stopBrowserGeneration(){engine?.interruptGenerate();}
export async function generateBrowser(plan:BrowserPlan,signal:AbortSignal,status:(text:string)=>void){
 if(!engine)throw new Error('ブラウザAIを先に準備してください。');
 const interrupt=()=>engine?.interruptGenerate();signal.addEventListener('abort',interrupt,{once:true});
 const complete=async(system:string,payload:unknown)=>{
  signal.throwIfAborted();
  const response=await engine!.chat.completions.create({messages:[{role:'system',content:system},{role:'user',content:JSON.stringify(payload)}],stream:false,temperature:0,max_tokens:1100,extra_body:{enable_thinking:false},response_format:{type:'json_object',schema:JSON.stringify(plan.schema)}});
  signal.throwIfAborted();if(response.choices[0]?.finish_reason!=='stop')throw new Error('AIの生成終了を確認できませんでした（'+response.choices[0]?.finish_reason+'）。');
  // WebLLM includes its disabled-thinking reply prefix in message.content.
  const content=(response.choices[0].message.content||'').replace(/^\s*<think>[\s\S]*?<\/think>\s*/,'').replace(/^```(?:json)?\s*/,'').replace(/\s*```$/,'');
  return JSON.parse(content);
 };
 try{status('端末のAIが回答を作成しています');const draft=await complete(plan.system,plan.payload);status('回答と出典を照合しています');return await complete(plan.system+' 校閲者として草案をsourcesと一文ずつ照合し、誤読・無関係な節を取り除いた最終JSONだけを返す。',{...plan.payload,reviewedExamples:[],draft});}
 finally{signal.removeEventListener('abort',interrupt);await engine.resetChat();}
}
